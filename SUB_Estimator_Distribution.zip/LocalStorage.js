const STORAGE_KEY = 'sub_estimations_v1';

function loadRawStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    console.error('loadRawStorage parse error', e);
    return null;
  }
}

// write raw value to localStorage
function saveRawStorage(value) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('saveRawStorage error', e);
    return false;
  }
}

// get current username from sessionStorage (auth.js sets session under window.AUTH_KEY or 'sub_app_user_v1')
function getCurrentUsername() {
  try {
    const key = (window.AUTH_KEY || 'sub_app_user_v1');
    const raw = sessionStorage.getItem(key);
    if (!raw) return null;
    const s = JSON.parse(raw);
    return s && s.username ? String(s.username) : null;
  } catch (e) {
    return null;
  }
}

// normalize - return array of entries for current user (or guest) regardless of stored format
function getSavedListFromStorage() {
  const raw = loadRawStorage();

  // legacy: stored as array -> return array
  if (Array.isArray(raw)) return raw;

  // new format: object { users: { username: [..] }, currentUser: 'username' }
  if (raw && typeof raw === 'object') {
    const user = getCurrentUsername() || raw.currentUser || 'guest';
    if (!raw.users) return [];
    const list = raw.users[user];
    return Array.isArray(list) ? list : [];
  }

  // empty
  return [];
}

// internal helper: ensure storage object (convert legacy array to object if needed)
function ensureStorageObject() {
  const raw = loadRawStorage();
  if (!raw) {
    const obj = { users: {}, currentUser: null };
    saveRawStorage(obj);
    return obj;
  }
  // if legacy array, convert to object with guest key
  if (Array.isArray(raw)) {
    const obj = { users: { guest: raw }, currentUser: null };
    saveRawStorage(obj);
    return obj;
  }
  // already object
  return raw;
}

// save entry (keeps backward compatibility: if storage was array it is migrated to object)
function saveToLocalStorage(entry) {
  try {
    let raw = loadRawStorage();
    // migrate legacy array -> object
    if (Array.isArray(raw) || raw === null) {
      const arr = Array.isArray(raw) ? raw : [];
      const obj = { users: { guest: arr }, currentUser: null };
      raw = obj;
    }
    // now raw is expected to be object
    if (!raw.users || typeof raw.users !== 'object') raw.users = {};

    const user = getCurrentUsername() || raw.currentUser || 'guest';

    // IMPORTANT: ensure the user's slot is an array (coerce malformed values)
    if (!Array.isArray(raw.users[user])) {
      // if there is an object (old/malformed), try to convert to array of values, otherwise reset to []
      if (raw.users[user] && typeof raw.users[user] === 'object') {
        try {
          // if it's an object with numeric keys, convert to array
          const maybeArr = Object.keys(raw.users[user])
            .sort((a,b)=>Number(a)-Number(b))
            .map(k => raw.users[user][k])
            .filter(Boolean);
          raw.users[user] = Array.isArray(maybeArr) ? maybeArr : [];
        } catch (e) {
          raw.users[user] = [];
        }
      } else {
        raw.users[user] = [];
      }
    }

    entry._id = entry._id || entry.timestamp || ('id_' + Date.now());
    raw.users[user].unshift(entry);
    raw.currentUser = user;
    saveRawStorage(raw);
    // update UI
    try { renderSavedList(); } catch (e) { /* ignore */ }
    console.log('LocalStorage: saved entry for', user, entry._id);
    return true;
  } catch (e) {
    console.error('saveToLocalStorage error', e);
    return false;
  }
}

// delete entry by id (only in current user's list)
function deleteSavedEntry(id) {
  try {
    const raw = ensureStorageObject();
    const user = getCurrentUsername() || raw.currentUser || 'guest';
    if (!raw.users || !raw.users[user]) return false;
    raw.users[user] = raw.users[user].filter(it => it._id !== id);
    saveRawStorage(raw);
    try { renderSavedList(); } catch (e) {}
    return true;
  } catch (e) {
    console.error('deleteSavedEntry error', e);
    return false;
  }
}

// find by id (in current user's list)
function findSavedById(id) {
  const list = getSavedListFromStorage();
  return list.find(it => it._id === id);
}

// render list UI (same buttons: ดู / โหลด / ลบ)
function renderSavedList() {
  const container = document.getElementById('saved-list');
  if (!container) return;
  const list = getSavedListFromStorage();
  if (!list || list.length === 0) {
    container.innerHTML = '<div style="color:#666">ยังไม่มีข้อมูลที่บันทึกไว้</div>';
    return;
  }
  container.innerHTML = list.map(it => {
    const title = (it.wa || '-') + ' | ' + (it.dateOnly || '') + ' | ยอด:' + (it.totalPrice || it.unitPrice || '0.00');
    return `<div style="display:flex;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid #f0f0f0">
      <div style="flex:1;font-size:13px">${escapeHtml(title)}</div>
      <div style="display:flex;gap:6px">
        <button type="button" onclick="openSaved('${it._id}')">ดู</button>
        <button type="button" onclick="loadSavedToForm('${it._id}')">โหลดเข้าแบบฟอร์ม</button>
        <button type="button" onclick="deleteSavedEntry('${it._id}')">ลบ</button>
      </div>
    </div>`;
  }).join('');
}

// preview renderer (kept similar to previous)
function renderSavedPreview(saved) {
  const out = document.getElementById('saved-output');
  if (!out) return;

  // use Index.html's renderItemsTable if present, otherwise provide fallback
  const renderItems = (typeof window.renderItemsTable === 'function')
    ? window.renderItemsTable
    : function(items){
      if (!items || items.length === 0) return '<div style="color:#666">ไม่มีรายการ</div>';
      const rows = items.map(r => `<tr>
        <td style="padding:6px;border:1px solid #ddd">${escapeHtml(r.no)}</td>
        <td style="padding:6px;border:1px solid #ddd;text-align:right">${escapeHtml(r.qty)}</td>
        <td style="padding:6px;border:1px solid #ddd;text-align:right">${escapeHtml(r.price)}</td>
        <td style="padding:6px;border:1px solid #ddd">${escapeHtml(r.desc)}</td>
        <td style="padding:6px;border:1px solid #ddd;text-align:right">${escapeHtml(r.total)}</td>
      </tr>`).join('');
      return `<table class="items-table" style="width:100%;border-collapse:collapse;margin-top:8px"><thead>
        <tr>
          <th style="padding:6px;border:1px solid #ddd;background:#f6f6f6">No</th>
          <th style="padding:6px;border:1px solid #ddd;background:#f6f6f6">Qty</th>
          <th style="padding:6px;border:1px solid #ddd;background:#f6f6f6">Price</th>
          <th style="padding:6px;border:1px solid #ddd;background:#f6f6f6">Description</th>
          <th style="padding:6px;border:1px solid #ddd;background:#f6f6f6">Total</th>
        </tr>
      </thead><tbody>${rows}</tbody></table>`;
    };

  const html = `
  <style>
    /* Maximize content to fill A4 landscape area */
    /* A4 landscape at ~96dpi -> 1123 x 793 px */
   /* Make the white background auto-size to content so it fits tightly
     when rendered to preview or PDF. We remove fixed px width/height and
     use inline-block so the container wraps its children. max-width:100%
     preserves responsiveness when shown on smaller screens. */
   .pdf-page { display:inline-block; width:auto; height:auto; max-width:100%; box-sizing:border-box; padding:6px; margin:0; background:#fff; color:#111; font-size:13px; }
    .pdf-page h2 { font-size:20px; margin:2px 0 6px; }
    .pdf-page h3 { font-size:14px; margin:6px 0 4px; }
    .pdf-page .items-table { width:100%; border-collapse:collapse; table-layout:fixed; font-size:12px; }
    .pdf-page .items-table col:nth-child(1){ width:6%; }
    .pdf-page .items-table col:nth-child(2){ width:8%; }
    .pdf-page .items-table col:nth-child(3){ width:10%; }
    .pdf-page .items-table col:nth-child(4){ width:62%; }
    .pdf-page .items-table col:nth-child(5){ width:14%; }
    .pdf-page .items-table th, .pdf-page .items-table td { padding:6px 6px; vertical-align:middle; }
    .pdf-page .items-table th { background:#f6f6f6; font-size:12px; }
    /* reduce signature block so table uses more vertical space */
    .pdf-page .sig-table td { padding:8px; height:72px; }
    /* reduce margins around totals */
    .pdf-page .totals { font-size:12px; margin-top:6px; }
    /* layout for side-by-side Power/Control */
    .pdf-page .pc-row { display:flex; gap:12px; flex-wrap:wrap; }
    .pdf-page .pc-col { flex:1; min-width:320px; }
  </style>

  <!-- use an inline-block wrapper so the white background fits the content exactly -->
  <div class="pdf-stage"><div class="pdf-page" style="display:inline-block;background:#fff;padding:6px;color:#111;box-sizing:border-box;">
    <h2 style="margin:4px 0 6px">การประมาณราคาค่าแรง SUB</h2>

    <div style="display:flex;gap:12px;margin-bottom:8px;flex-wrap:wrap">
      <div style="min-width:180px"><strong>SUB:</strong> ${escapeHtml(saved.subName||'')}</div>
      <div style="min-width:120px"><strong>WA:</strong> ${escapeHtml(saved.wa||'')}</div>
      <div style="min-width:220px"><strong>Project:</strong> ${escapeHtml(saved.project||'')}</div>
      <div style="min-width:120px"><strong>Cubicle:</strong> ${escapeHtml(saved.cubicle||'')}</div>
      <div style="min-width:120px"><strong>Serial:</strong> ${escapeHtml(saved.serial||'')}</div>

    </div>

    <div class="pc-row" style="margin-top:8px">
      <div class="pc-col">
        <h3 style="margin:8px 0 4px">Power</h3>
        ${renderItems(saved.power)}
      </div>
      <div class="pc-col">
        <h3 style="margin:8px 0 4px">Control</h3>
        ${renderItems(saved.control)}
      </div>
    </div>

    <div style="margin-top:12px;text-align:right">
      <div><strong>Unit price (per set):</strong> ${escapeHtml(saved.unitPrice||'0.00')}</div>
      <div>
        <span style="margin-right:8px"><strong>Sets:</strong> ${escapeHtml((saved.totalSet !== undefined && saved.totalSet !== null) ? saved.totalSet : '1')}</span>
        <span><strong>Total:</strong> ${escapeHtml(saved.totalPrice||'0.00')}</span>
      </div>
      <div style="margin-top:6px;text-align:right;font-size:12px;color:#333;margin-bottom:12px">(${escapeHtml(numberToThaiText(saved.totalPrice || saved.unitPrice || '0.00'))})</div>

    <!-- signature table -->
  <table class="sig-table" style="width:100%;border-collapse:collapse;box-sizing:border-box;margin-top:12px;">
      <colgroup>
        <col style="width:25%"><col style="width:25%"><col style="width:25%"><col style="width:25%">
      </colgroup>
      <tbody>
        <tr>
          <td style="padding:12px;border:1px solid #000;vertical-align:bottom;height:96px">
            <div style="display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;box-sizing:border-box">
              <div style="height:50px"></div>
              <div style="font-size:12px;color:#555;margin-top:14px">ผู้ตรวจรับงาน(SUB)<br></div>
              <div style="color:#666;font-size:12px;margin-top:6px">วันที่........./........./.........</div>
            </div>
          </td>
          <td style="padding:12px;border:1px solid #000;vertical-align:bottom;height:96px">
            <div style="display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;box-sizing:border-box">
              <div style="height:50px"></div>
              <div style="font-size:12px;color:#555;margin-top:14px">หัวหน้าผู้ควบคุมงาน(ผู้ดูแลSUB)<br></div>
              <div style="color:#666;font-size:12px;margin-top:6px">วันที่........./........./.........</div>
            </div>
          </td>
          <td style="padding:12px;border:1px solid #000;vertical-align:bottom;height:96px">
            <div style="display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;box-sizing:border-box">
              <div style="height:50px"></div>
              <div style="font-size:12px;color:#555;margin-top:14px">ผจก.แผนก/ฝ่ายผลิตงานไฟฟ้า<br></div>
              <div style="color:#666;font-size:12px;margin-top:6px">วันที่........./........./.........</div>
            </div>
          </td>
          <td style="padding:12px;border:1px solid #000;vertical-align:bottom;height:96px">
            <div style="display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;box-sizing:border-box">
              <div style="height:50px"></div>
              <div style="font-size:12px;color:#555;margin-top:14px">ผจก.แผนก/ฝ่ายวางแผน<br></div>
              <div style="color:#666;font-size:12px;margin-top:6px">วันที่........./........./.........</div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div style="color:#666;font-size:12px;margin-top:6px">FM-PMEP-010(01)
    <div style="color:#666;font-size:12px;margin-top:6px">เริ่มใช้ 14 มี.ค. 2568
    </div>

  </div></div>
  `;
  out.innerHTML = html;
}

// open, load, helpers
function openSaved(id) {
  const it = findSavedById(id);
  if (!it) return alert('ไม่พบรายการที่เลือก');
  renderSavedPreview(it);
}

function loadSavedToForm(id) {
  const it = findSavedById(id);
  if (!it) return alert('ไม่พบรายการที่เลือก');
  document.getElementById('subName').value = it.subName || '';
  document.getElementById('wa').value = it.wa || '';
  document.getElementById('project').value = it.project || '';
  document.getElementById('cubicle').value = it.cubicle || '';
  document.getElementById('serial').value = it.serial || '';
  document.getElementById('total-set').value = it.totalSet || 1;

  const pb = document.getElementById('power-table-body');
  const cb = document.getElementById('control-table-body');
  if (pb) pb.innerHTML = '';
  if (cb) cb.innerHTML = '';

  (it.power || []).forEach(r => addRow('power', { no: r.no, qty: r.qty, price: r.price, desc: r.desc }));
  (it.control || []).forEach(r => addRow('control', { no: r.no, qty: r.qty, price: r.price, desc: r.desc }));

  try { updateTotal('power'); updateTotal('control'); updateSummary(); } catch(e){}
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// small helpers
function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
}

// convert number to Thai text (supports decimal up to 2 places for satang)
function numberToThaiText(val) {
  try {
    let num = parseFloat(String(val).replace(/,/g, '')) || 0;
    const units = ['ศูนย์','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า'];
    const positions = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];

    function integerToText(n) {
      if (n === 0) return 'ศูนย์';
      let out = '';
      const s = String(n);
      const len = s.length;
      for (let i = 0; i < len; i++) {
        const digit = parseInt(s.charAt(i));
        const pos = len - i - 1;
        const posName = positions[pos % 6] || '';
        if (digit === 0) continue;
        if (pos === 1 && digit === 1) {
          out += 'สิบ';
        } else if (pos === 1 && digit === 2) {
          out += 'ยี่' + 'สิบ';
        } else if (pos === 0 && digit === 1 && len > 1) {
          out += 'เอ็ด';
        } else {
          out += units[digit] + posName;
        }
      }
      return out;
    }

    const baht = Math.floor(num);
    const satang = Math.round((num - baht) * 100);

    let result = '';
    // handle millions groups
    function groupConvert(n) {
      if (n < 1000000) return integerToText(n);
      const high = Math.floor(n / 1000000);
      const rest = n % 1000000;
      let r = '';
      r += integerToText(high) + 'ล้าน';
      if (rest > 0) r += integerToText(rest);
      return r;
    }

    result = groupConvert(baht) + ' บาท';
    if (satang === 0) result += 'ถ้วน';
    else result += groupConvert(satang) + ' สตางค์';
    return result;
  } catch (e) {
    return '' + val;
  }
}

// auto render on load
document.addEventListener('DOMContentLoaded', () => {
  try { renderSavedList(); } catch (e) {}
});

// expose API
window.getSavedListFromStorage = getSavedListFromStorage;
window.saveToLocalStorage = saveToLocalStorage;
window.deleteSavedEntry = deleteSavedEntry;
window.renderSavedList = renderSavedList;
window.findSavedById = findSavedById;
window.renderSavedPreview = renderSavedPreview;
window.openSaved = openSaved;
window.loadSavedToForm = loadSavedToForm;
