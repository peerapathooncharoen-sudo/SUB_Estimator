<#
updater.ps1 - Simple updater for SUB Estimator

Place this file in the installed application folder (e.g. %LocalAppData%\SUB Estimator) and
create a scheduled task or run-at-login shortcut to run it periodically.

Configuration: edit the $MetaUrl variable to point to your hosted version.json (HTTPS).

Behavior summary:
 - download version.json
 - if remote version > local version -> download zip, verify sha256
 - extract to temp, backup existing install, move new files into place, write version.txt
#>

[CmdletBinding()]
Param(
  [string]$MetaUrl = 'https://example.com/releases/version.json',
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$BackupDirBase = "$env:LocalAppData\SUB Estimator_backup"
)

function Get-LocalVersion {
  $vfile = Join-Path $InstallDir 'version.txt'
  if (Test-Path $vfile) { return (Get-Content $vfile -ErrorAction SilentlyContinue).Trim() }
  return '0.0.0'
}

function Is-Newer($remote, $local) {
  $r = $remote.Split('.') | ForEach-Object {[int]$_}
  $l = $local.Split('.')  | ForEach-Object {[int]$_}
  for ($i=0; $i -lt [Math]::Max($r.Count,$l.Count); $i++) {
    $ri = if ($i -lt $r.Count) { $r[$i] } else { 0 }
    $li = if ($i -lt $l.Count) { $l[$i] } else { 0 }
    if ($ri -gt $li) { return $true }
    if ($ri -lt $li) { return $false }
  }
  return $false
}

try {
  Write-Output "Updater: checking $MetaUrl ..."
  $meta = Invoke-RestMethod -Uri $MetaUrl -UseBasicParsing -ErrorAction Stop

  # If the server served JSON as text (or included a UTF8 BOM), ConvertFrom-Json
  if ($meta -is [string]) {
    $raw = $meta.Trim()
    # strip UTF8 BOM bytes (EF BB BF) and Unicode BOM (FEFF) if present
    $raw = $raw -replace "^[\xEF\xBB\xBF]+",""
    $raw = $raw -replace '^[\uFEFF]+',''
    try {
      $meta = $raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
      throw "Failed to parse version metadata as JSON. Raw data starts with: $($raw.Substring(0,[Math]::Min(80,$raw.Length))) - error: $_"
    }
  }

  $remoteVersion = $meta.version
  $remoteUrl = $meta.url
  $remoteSha = $meta.sha256

  if (-not $remoteVersion -or -not $remoteUrl -or -not $remoteSha) {
    throw "Invalid metadata received from $MetaUrl - missing required fields (version, url, sha256)"
  }

  $localVersion = Get-LocalVersion
  Write-Output "Local version: $localVersion  Remote version: $remoteVersion"

  if (-not (Is-Newer $remoteVersion $localVersion)) {
    Write-Output "Updater: up-to-date."
    exit 0
  }

  $tmpZip = Join-Path $env:TEMP ("sub_update_{0}.zip" -f ([guid]::NewGuid().ToString()))
  Write-Output "Downloading $remoteUrl -> $tmpZip"
  Invoke-WebRequest -Uri $remoteUrl -OutFile $tmpZip -UseBasicParsing -ErrorAction Stop

  $h = (Get-FileHash -Algorithm SHA256 -Path $tmpZip).Hash.ToUpper()
  if ($h -ne $remoteSha.ToUpper()) { throw "SHA256 mismatch (expected $remoteSha, got $h)" }

  $extractDir = Join-Path $env:TEMP ("sub_update_extract_{0}" -f ([guid]::NewGuid().ToString()))
  New-Item -ItemType Directory -Path $extractDir | Out-Null
  Expand-Archive -Path $tmpZip -DestinationPath $extractDir -Force

  # backup current install
  if (Test-Path $InstallDir) {
    $ts = Get-Date -Format "yyyyMMddHHmmss"
    $bak = "${BackupDirBase}_$ts"
    Write-Output "Backing up current install to $bak"
    Remove-Item -Recurse -Force $bak -ErrorAction SilentlyContinue
    # use Move-Item to move the folder to the backup path
    Move-Item -Path $InstallDir -Destination $bak -Force
  }

  Write-Output "Installing new files to $InstallDir"
  # Ensure destination parent exists and create InstallDir
  $parent = Split-Path -Parent $InstallDir
  if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent | Out-Null }
  if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir | Out-Null }
  # Move extracted content into place (move contents of extractDir into InstallDir)
  try {
    Move-Item -Path (Join-Path $extractDir '*') -Destination $InstallDir -Force -ErrorAction Stop
  } catch {
    throw "Failed to move extracted files into place: $_"
  }

  # write version
  $remoteVersion | Out-File -FilePath (Join-Path $InstallDir 'version.txt') -Encoding UTF8

  Remove-Item -Path $tmpZip -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $extractDir -Recurse -Force -ErrorAction SilentlyContinue

  Write-Output "Update to $remoteVersion completed."
} catch {
  Write-Error "Updater failed: $_"
  exit 1
}
