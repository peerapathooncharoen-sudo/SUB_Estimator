﻿# Download required libraries into lib\ (PowerShell)
$ErrorActionPreference = 'Stop'

$libDir = Join-Path $PSScriptRoot '..\lib' | Resolve-Path -Relative
if (-not (Test-Path -Path $libDir)) {
    New-Item -ItemType Directory -Path $libDir | Out-Null
}

$files = @(
    @{ url = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js'; out = 'html2canvas.min.js' },
    @{ url = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'; out = 'jspdf.umd.min.js' }
)

foreach ($f in $files) {
    $outPath = Join-Path $libDir $f.out
    try {
        Write-Host "Downloading $($f.url) -> $outPath"
        Invoke-WebRequest -Uri $f.url -OutFile $outPath -UseBasicParsing
        Write-Host "Saved $outPath"
    } catch {
        Write-Error "Failed to download $($f.url): $_"
    }
}

Write-Host "Done. Ensure the files are present in the lib folder before running Index.html."
