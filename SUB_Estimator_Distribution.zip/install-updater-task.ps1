<#
install-updater-task.ps1
Installs a per-user scheduled task to run updater.ps1 at user logon.

Usage:
  powershell -ExecutionPolicy Bypass -File .\install-updater-task.ps1
#>
Param(
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$TaskName = 'SUB Estimator Updater'
)

$updaterPath = Join-Path $InstallDir 'updater.ps1'
if (-not (Test-Path $updaterPath)) { Write-Error "updater.ps1 not found at $updaterPath" ; exit 1 }

$action = New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updaterPath`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive

try {
  Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $TaskName -Principal $principal -Force | Out-Null
  Write-Host "Scheduled task '$TaskName' installed for user $env:USERNAME"
} catch {
  Write-Error "Failed to register scheduled task: $_"
  exit 1
}
