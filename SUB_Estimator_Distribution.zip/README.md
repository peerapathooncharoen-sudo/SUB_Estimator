SUB Estimator — Quick start

What this is
- A static, browser-based SUB estimator app. Open `Index.html` in a modern browser to use.

Included files
- `Index.html` — main UI
- `Auth.js` — simple local user/auth helpers (localStorage/sessionStorage)
- `LocalStorage.js` — project-specific storage helpers
- `DatabasePW.js`, `DatabaseCT.js` — item databases
- `lib/` — bundled libraries: `html2canvas.min.js`, `jspdf.umd.min.js`
- `scripts/download-libs.ps1` — PowerShell helper to download libraries if needed

Quick run (recommended)
1. From a terminal in the project folder, run a simple static server (recommended to avoid CORS quirks):

```powershell
python -m http.server 8000
```

2. Open a browser and go to: http://localhost:8000

Alternative: double-click `Index.html` to open directly in the browser (may work, but running a local server is more reliable).

Security & first-run
- Auth note: This distribution DOES NOT auto-create a default admin account. If no users exist you must create the first account manually:
  - Open browser DevTools Console and run:

```javascript
await registerUser('your-username','your-password');
setSession('your-username');
```

- For local development only, you can enable auto-creation by setting `AUTO_CREATE_DEFAULT_ADMIN = true` in `Auth.js` (NOT recommended for distribution).

Troubleshooting
- If PDF download doesn't work, ensure `lib/html2canvas.min.js` and `lib/jspdf.umd.min.js` exist. To fetch them automatically, run `scripts\download-libs.ps1` (PowerShell).
- If storage seems empty, check the browser's Local Storage / Session Storage for keys `sub_app_users_v1` and `sub_estimations_v1`.

How to package for distribution
- Remove unrelated installer files (e.g., `unins000.exe`, `unins000.dat`) to keep package clean.
- ZIP the project folder and include this `README.md` so recipients know how to run and create the first user.

Installer / การแจกจ่าย
- หากคุณสร้างไฟล์ติดตั้งด้วย Inno Setup (`SUB_Estimator_Installer.exe`) ให้แจกไฟล์ `.exe` ให้ผู้รับโดยตรง (อีเมล, แชร์ลิงก์, USB)
- แนะนำให้แจกพร้อมไฟล์ checksum (SHA256) เพื่อให้ผู้รับตรวจความสมบูรณ์ของไฟล์ก่อนรัน:

Compile & Prepare release (one command)
--------------------------------------
ถ้าต้องการคอมไพล์ `SUB_Estimator.iss` เป็นตัวติดตั้งและสร้าง `release.zip` ให้ใช้สคริปต์เดียว (ต้องติดตั้ง Inno Setup):

```powershell
# เปิด PowerShell เป็น Administrator แล้วรัน
powershell -ExecutionPolicy Bypass -File .\compile-and-release.ps1
```

สิ่งที่สคริปต์จะทำ:
- ค้นหา `ISCC.exe` (Inno Setup Compiler) และคอมไพล์ `.iss` เป็น `.exe`
- หาไฟล์ `.exe` ที่ถูกสร้างแล้วเรียก `create-release.ps1` เพื่อคัดลอกไฟล์, สร้าง SHA256 และ zip เป็น `release.zip`

หากสคริปต์แจ้งว่าไม่พบ `ISCC.exe` ให้ติดตั้ง Inno Setup แล้วรันคำสั่งคอมไพล์ด้วยตัวเอง:

```powershell
& 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe' 'C:\Users\Admin\Desktop\SUB Estimator\SUB_Estimator.iss'
```

หมายเหตุ: ต้องรันคำสั่งในบัญชีที่มีสิทธิ์ติดตั้ง (Administrator) เพื่อให้ Inno Setup สร้าง installer ที่ต้องการสิทธิ์สูงสุด
```powershell
# สร้าง SHA256 checksum (บนเครื่องผู้ส่ง)
> Get-FileHash -Algorithm SHA256 .\SUB_Estimator_Installer.exe | Format-List
```

- ตัวอย่างวิธีแจก:
  - อีเมล (ไฟล์เล็กกว่า 25MB) — แนบ `.exe` และไฟล์ `.sha256.txt` ที่มีค่า checksum
  - แชร์ผ่าน Cloud (OneDrive/Google Drive/Dropbox) — อัปโหลด `.exe` แล้วแชร์ลิงก์แบบ Private
  - GitHub Release — อัปโหลดไฟล์เป็น Release asset เพื่อให้ดาวน์โหลดและเก็บเวอร์ชันได้
  - USB / Network share — วางไฟล์ลง USB พร้อม README

- คำแนะนำสำหรับผู้รับ (Windows):
  1. ตรวจสอบ SHA256 (PowerShell):

```powershell
Get-FileHash -Algorithm SHA256 'C:\path\to\SUB_Estimator_Installer.exe'
```

  2. ดับเบิลคลิกไฟล์ `.exe` เพื่อรันตัวติดตั้ง (อาจต้องสิทธิ์ผู้ดูแลระบบ) หรือคลิกขวา -> Run as administrator
  3. เมื่อติดตั้งเสร็จ โปรแกรมจะสร้าง shortcut ที่ Desktop/Start Menu ตามที่ผู้ติดตั้งเลือก
  4. หากต้องการติดตั้งแบบไม่ต้องโต้ตอบ (silent):

```powershell
Start-Process -FilePath 'C:\path\to\SUB_Estimator_Installer.exe' -ArgumentList '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART' -Wait
```

Uninstall
- ใช้ Control Panel -> Programs and Features หรือ Settings -> Apps เพื่อถอนการติดตั้ง
- หรือนำทางไปยังโฟลเดอร์การติดตั้งแล้วรัน `unins000.exe` (ที่สร้างโดย Inno Setup)

Contact
- No contact included. Edit `README.md` to add author/maintainer details if needed.
