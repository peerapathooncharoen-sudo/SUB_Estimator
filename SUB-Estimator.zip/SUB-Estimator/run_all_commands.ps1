# Run full auto-update preparation + test pipeline and capture outputs to smoketest_outputs/
param(
  [string]$ProjectRoot = 'C:\Users\Admin\Desktop\SUB Estimator',
  [string]$Version = '1.2.0'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptROOT).Path

Write-Host "Running main pipeline: build -> smoke -> finalize"

$run = Join-Path $scriptRoot 'scripts\do_everything_local.ps1'
if (Test-Path $run) { & powershell -NoProfile -ExecutionPolicy Bypass -File $run } else { Write-Warning "do_everything_local.ps1 missing" }

$bundle = Join-Path $scriptRoot 'scripts\create_bundle_zip.ps1'
if (Test-Path $bundle) { & powershell -NoProfile -ExecutionPolicy Bypass -File $bundle } else { Write-Warning "create_bundle_zip.ps1 missing" }

$final = Join-Path $scriptRoot 'scripts\finalize_and_check.ps1'
if (Test-Path $final) { & powershell -NoProfile -ExecutionPolicy Bypass -File $final } else { Write-Warning "finalize_and_check.ps1 missing" }

Write-Host "run_all_commands completed."

# 1) download libs
Run-Capture '01_download-libs' { Join-Path $ProjectRoot 'scripts\download-libs.ps1' }

# 2) build ZIP & 3) write metadata
Run-Capture '02_build-and-publish' { "{0} -Version {1} -Force" -f (Join-Path $ProjectRoot 'scripts\build-and-publish.ps1'), $Version }

# 4) create_local_meta (safety) - will write dist/version.json and root version.json
Run-Capture '03_create_local_meta' { "{0} -ZipPath '{1}' -Version {2}" -f (Join-Path $ProjectRoot 'create_local_meta.ps1'), (Join-Path $ProjectRoot 'dist\SUB_Estimator_program.zip'), $Version }

# 5) install program and register updater (per-user). Run as normal user (fallback to schtasks if Register-ScheduledTask denied).
Run-Capture '04_install_register' { "{0} -SourceZip '{1}' -RegisterUpdater" -f (Join-Path $ProjectRoot 'install.ps1'), (Join-Path $ProjectRoot 'dist\SUB_Estimator_program.zip') }

# --- safe schtasks query: capture stdout/stderr and exit code without throwing ---
$taskName = "SUB Estimator Updater"
$schtasksOut = Join-Path $outDir '05_schtasks_query.txt'
Write-Host "=== Query scheduled task -> $schtasksOut"

try {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = "schtasks.exe"
  $psi.Arguments = "/Query /TN `"$taskName`" /V /FO LIST"
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError  = $true
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true

  $proc = New-Object System.Diagnostics.Process
  $proc.StartInfo = $psi
  if ($proc.Start()) {
    $out = $proc.StandardOutput.ReadToEnd()
    $err = $proc.StandardError.ReadToEnd()
    $proc.WaitForExit()
    ($out + "`n" + $err).Trim() | Out-File -FilePath $schtasksOut -Encoding UTF8
    if ($proc.ExitCode -ne 0) {
      Write-Host "schtasks exited with code $($proc.ExitCode) — task may not exist. See $schtasksOut"
    } else {
      Write-Host "schtasks query completed, output saved to $schtasksOut"
    }
  } else {
    "Failed to start schtasks.exe" | Out-File -FilePath $schtasksOut -Encoding UTF8
    Write-Warning "Failed to start schtasks.exe"
  }
} catch {
  # fallback: best-effort one-liner (non-terminating)
  schtasks /Query /TN "$taskName" /V /FO LIST 2>&1 | Out-File -FilePath $schtasksOut -Encoding UTF8
  Write-Warning "schtasks invocation failed in managed mode; used fallback. See $schtasksOut"
}

# 7) run updater manually against local dist/version.json
$distMeta = (Resolve-Path (Join-Path $ProjectRoot 'dist\version.json')).Path
$metaUri = "file:///" + ($distMeta -replace '\\','/')
$updaterInstalled = Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.ps1'
$upStdOut = Join-Path $outDir '06_updater_stdout.txt'
Write-Host "=== Invoke updater: $updaterInstalled -MetaUrl $metaUri -> $upStdOut"
if (Test-Path $updaterInstalled) {
  & powershell -NoProfile -ExecutionPolicy Bypass -File $updaterInstalled -MetaUrl $metaUri 2>&1 | Tee-Object -FilePath $upStdOut
} else {
  "updater.ps1 not found at $updaterInstalled" | Out-File -FilePath $upStdOut
}

# 8) collect installed updater.log and version.txt
if (Test-Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.log')) {
  Copy-Item -Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.log') -Destination (Join-Path $outDir '07_updater.log') -Force
}
if (Test-Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\version.txt')) {
  Copy-Item -Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\version.txt') -Destination (Join-Path $outDir '08_installed_version.txt') -Force
}

# 9) show dist metadata and zip SHA
Write-Host "=== dist/version.json ==="
Get-Content (Join-Path $ProjectRoot 'dist\version.json') -Raw | Tee-Object -FilePath (Join-Path $outDir '09_dist_version.json')

Write-Host "=== dist zip SHA256 ==="
Get-FileHash -Algorithm SHA256 (Join-Path $ProjectRoot 'dist\SUB_Estimator_program.zip') | Out-File -FilePath (Join-Path $outDir '10_dist_zip_hash.txt')

# 10) (optional) run smoketest pipeline (do_everything_local)
Run-Capture '11_do_everything_local' { Join-Path $ProjectRoot 'scripts\do_everything_local.ps1' }

Write-Host "=== DONE. Collected outputs in: $outDir ==="
Pop-Location
      Write-Host "schtasks exited with code $($proc.ExitCode) — task may not exist. See $schtasksOut"
    } else {
      Write-Host "schtasks query completed, output saved to $schtasksOut"
    }
  } else {
    "Failed to start schtasks.exe" | Out-File -FilePath $schtasksOut -Encoding UTF8
    Write-Warning "Failed to start schtasks.exe"
  }
} catch {
  # fallback: best-effort one-liner (non-terminating)
  schtasks /Query /TN "$taskName" /V /FO LIST 2>&1 | Out-File -FilePath $schtasksOut -Encoding UTF8
  Write-Warning "schtasks invocation failed in managed mode; used fallback. See $schtasksOut"
}

# 7) run updater manually against local dist/version.json
$distMeta = (Resolve-Path (Join-Path $ProjectRoot 'dist\version.json')).Path
$metaUri = "file:///" + ($distMeta -replace '\\','/')
$updaterInstalled = Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.ps1'
$upStdOut = Join-Path $outDir '06_updater_stdout.txt'
Write-Host "=== Invoke updater: $updaterInstalled -MetaUrl $metaUri -> $upStdOut"
if (Test-Path $updaterInstalled) {
  & powershell -NoProfile -ExecutionPolicy Bypass -File $updaterInstalled -MetaUrl $metaUri 2>&1 | Tee-Object -FilePath $upStdOut
} else {
  "updater.ps1 not found at $updaterInstalled" | Out-File -FilePath $upStdOut
}

# 8) collect installed updater.log and version.txt
if (Test-Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.log')) {
  Copy-Item -Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\updater.log') -Destination (Join-Path $outDir '07_updater.log') -Force
}
if (Test-Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\version.txt')) {
  Copy-Item -Path (Join-Path $env:LOCALAPPDATA 'SUB Estimator\version.txt') -Destination (Join-Path $outDir '08_installed_version.txt') -Force
}

# 9) show dist metadata and zip SHA
Write-Host "=== dist/version.json ==="
Get-Content (Join-Path $ProjectRoot 'dist\version.json') -Raw | Tee-Object -FilePath (Join-Path $outDir '09_dist_version.json')

Write-Host "=== dist zip SHA256 ==="
Get-FileHash -Algorithm SHA256 (Join-Path $ProjectRoot 'dist\SUB_Estimator_program.zip') | Out-File -FilePath (Join-Path $outDir '10_dist_zip_hash.txt')

# 10) (optional) run smoketest pipeline (do_everything_local)
Run-Capture '11_do_everything_local' { Join-Path $ProjectRoot 'scripts\do_everything_local.ps1' }

Write-Host "=== DONE. Collected outputs in: $outDir ==="
Pop-Location
