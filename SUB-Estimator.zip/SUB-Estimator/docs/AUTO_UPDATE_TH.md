คู่มือสั้นสำหรับระบบอัพเดตอัตโนมัติ (ภาษาไทย)

สรุปการทำงาน
- CI (GitHub Actions) จะสร้างไฟล์ `dist/SUB_Estimator_program.zip` และ `dist/version.json` ทุกครั้งที่รัน workflow
- ถ้าต้องการเผยแพร่ให้ผู้ใช้ปลายทางอัพเดตอัตโนมัติ ให้สร้าง Git tag (เช่น `v1.2.0`) หรือสั่ง workflow แบบแมนนวลพร้อม `publish=true` และระบุ `tag`
- Updater (`updater.ps1`) ถูกตั้งให้ตรวจสอบ URL: `https://github.com/<repo>/releases/latest/download/version.json` โดยค่าเริ่มต้น — เมื่อผู้ใช้เปิดเครื่องหรือ scheduled task รัน ตัว updater จะดาวน์โหลด `version.json` และอัพเดตถ้ามีเวอร์ชันใหม่

การติดตั้งบนเครื่องผู้ใช้ (ขั้นตอนสั้น)
1. คัดลอก `SUB_Estimator_program.zip` ไปยังเครื่องผู้ใช้
2. รันใน PowerShell (สิทธิ์ผู้ใช้ปกติ):
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install.ps1 -SourceZip .\SUB_Estimator_program.zip -RegisterUpdater
   ```
   - จะแตกไฟล์ไปที่ `%LocalAppData%\SUB Estimator`
   - จะเขียน `version.txt` ถ้ามีข้อมูลเวอร์ชัน
   - จะลง scheduled task (AtLogOn + Daily 03:00) เรียก `updater.ps1` เพื่อให้ระบบอัพเดตอัตโนมัติ

การทดสอบ (นักพัฒนา)
- Local watcher (ทันที):
  1. เปิด PowerShell ในโฟลเดอร์โปรเจค
  2. รัน:
     ```powershell
     powershell -ExecutionPolicy Bypass -File .\scripts\watch-and-build.ps1
     ```
  3. แก้ไฟล์ (เช่น `Index.html`) แล้วบันทึก — `dist/SUB_Estimator_program.zip` จะถูกสร้าง/อัพเดตอัตโนมัติ

- ทดสอบ CI + Release (ทาง remote):
  1. ผลงาน build ปกติ: push ไป `main` จะรัน workflow และสร้าง artifacts (คุณสามารถดาวน์โหลดจากหน้า Actions)
  2. เผยแพร่ให้ผู้ใช้ปลายทางอัพเดตโดยอัตโนมัติ: สร้าง git tag และ push ขึ้น origin เช่น:
     ```powershell
     git tag -a v1.2.0 -m "Release v1.2.0"
     git push origin v1.2.0
     ```
     - เมื่อ tag ถูก push, workflow จะทำ release อัตโนมัติและอัปโหลด `SUB_Estimator_program.zip` และ `version.json` เป็น release assets
  3. ตรวจสอบ `version.json` บน Release (หรือดาวน์โหลด asset) เพื่อยืนยันว่าฟิลด์ `url`/`version`/`sha256` ถูกต้อง

การบังคับให้อัพเดตเครื่องผู้ใช้ทันที
- บนเครื่องผู้ใช้ ให้รัน `updater.ps1` ด้วย PowerShell ดังนี้ (ตัวอย่าง):
  ```powershell
  powershell -ExecutionPolicy Bypass -File "%LocalAppData%\SUB Estimator\updater.ps1"
  ```
- ถ้าต้องการบังคับให้ไฟล์ ZIP ใหม่ถูกใช้โดย updater แต่ยังไม่ต้องการ publish เป็น Release จริง: อัปโหลด `version.json` และ zip ไปยังที่ฝากไฟล์ที่ updater อ่าน (หรือแก้ MetaUrl ของ updater ชั่วคราวให้ชี้ไปยังไฟล์ทดสอบ local/file:// URI)

ข้อควรระวัง
- ถ้า branch `main` ถูกป้องกัน (protected) การพยายาม push ด้วย workflow อาจถูกปฏิเสธ — วิธีที่ปลอดภัยคือใช้การสร้าง Release (ที่ผมเพิ่มให้เมื่อ push tag)
- GitHub token ที่ใช้โดย Actions (`GITHUB_TOKEN`) มีสิทธิ์สร้าง release และอัพโหลด assets ใน repository เดียวกัน แต่หากต้องการ push เข้า branch protected ด้วยสิทธิ์พิเศษ อาจต้องใช้ Personal Access Token (PAT) และตั้งค่าเป็น secret

ถ้าคุณต้องการ ผมจะทำขั้นตอนเพิ่มเติม:
- เพิ่มตัวเลือกให้ workflow อัปโหลดไปยัง GitHub Releases สำหรับ manual dispatch (ผมได้เพิ่มแล้ว) และให้ run อัตโนมัติเมื่อ push tag `v*` (ผมได้เพิ่ม trigger)
- เพิ่มตัวอย่างสคริปต์เพื่อ force-update เครื่องผู้ใช้จากระยะไกล (เช่นผ่าน PSRemoting)

ข้อความสรุป: ระบบตอนนี้พร้อมใช้ — แค่สร้าง tag (เช่น `v1.2.0`) แล้ว push ขึ้น origin ระบบจะสร้าง Release และผู้ใช้ที่ติดตั้ง updater จะได้รับการอัพเดตอัตโนมัติเมื่อ updater ทำงานครั้งถัดไป
