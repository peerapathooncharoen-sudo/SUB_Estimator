# Placeholder / incomplete files — developer checklist

This file lists files that were placeholders or intentionally minimal and what they should implement:

- updater.ps1 (root): wrapper to call authoritative dist/updater.ps1. OK (wrapper implemented).
- install-updater-task.ps1 (root): must install per-user scheduled task; completed by replacing with working copy.
- check_auto_update.ps1: small test runner to exercise updater (implemented).
- scripts/run_full_pipeline_and_package.ps1: orchestrator for local pipeline + bundle (implemented).
- scripts/check_ready_before_run.ps1: pre-run checks (implemented).
- scripts/client_quick_install.ps1: convenience wrapper to call install.ps1 (implemented).
- scripts/release_publish_and_sign.ps1: publish and optional signing (implemented).
- scripts/collect_and_package_outputs.ps1: collect smoketest outputs and zip (implemented).
- run_all_commands.ps1: orchestrator to run major steps (implemented).
- scripts/finalize_and_check.ps1: was truncated — completed to write concise summary (finalize_summary.txt/.json).

If you want fuller behaviour (e.g., stronger signing workflow, CI secrets handling, robust logging), note the TODOs inside corresponding scripts.
   หรือ (ถ้ามี zip แล้ว)
   powershell -NoProfile -ExecutionPolicy Bypass -File .\create_local_meta.ps1 -ZipPath ".\dist\SUB_Estimator_program.zip" -Version 1.2.0

   ตรวจ: dist\version.json ถูกเขียนและค่า sha256 ตรงกับ Get-FileHash

4) ติดตั้งโปรแกรมลงเครื่อง (per-user) และลง scheduled task (RegisterUpdater)
   powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -SourceZip .\dist\SUB_Estimator_program.zip -RegisterUpdater

   หากต้องการให้ Register-ScheduledTask ทำงานครบ AtLogOn+Daily ให้เปิด PowerShell เป็น Administrator ก่อนรันคำสั่งด้านบน

5) ยืนยัน scheduled task
   schtasks /Query /TN "SUB Estimator Updater" /V /FO LIST
   หากไม่พบ ให้รัน fallback (per-user) ด้วย schtasks (ตัวอย่าง):
   schtasks /Create /TN "SUB Estimator Updater" /TR "PowerShell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"C:\Users\Admin\AppData\Local\SUB Estimator\updater.ps1\" -MetaUrl \"file:///C:/Users/Admin/Desktop/SUB Estimator/dist/version.json\"" /SC ONLOGON /RL LIMITED /F /RU "%USERNAME%"

6) ทดสอบ updater ด้วยมือ (ชี้ไปที่ dist/version.json)
   $meta=(Resolve-Path .\dist\version.json).Path
   $uri="file:///"+($meta -replace '\\','/')
   powershell -NoProfile -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\SUB Estimator\updater.ps1" -MetaUrl $uri

   ตรวจ stdout: ข้อความตรวจเวอร์ชัน, ดาวน์โหลด, ตรวจ SHA256, Update completed หรือ Up-to-date

7) ตรวจ log ของ updater
   Get-Content "$env:LOCALAPPDATA\SUB Estimator\updater.log" -Tail 200

   หากเจอ error ให้เก็บข้อความแล้วแก้สคริปต์ตามข้อผิดพลาด (เช่น path ไม่พบ, SHA mismatch, ไฟล์ล็อค)

8) รวบรวม smoketest outputs (ถ้าใช้)
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\do_everything_local.ps1 -Version 1.2.0
   หรือรันสคริปต์เก็บผล:
   powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\collect_and_package_outputs.ps1

   ไฟล์ผลจะอยู่ใน smoketest_outputs/ หรือ auto_check_results_YYYYMMDD_HHMMSS.zip

9) ยืนยันผลสุดท้าย
   - %LocalAppData%\SUB Estimator\version.txt เป็นเวอร์ชันที่คาดไว้
   - scheduled task มีอยู่และชี้ไปที่ updater.ps1
   - updater.log แสดง "Update to X completed." หรือ "up-to-date."
   - dist/version.json.sha256 ตรงกับ Get-FileHash ของ ZIP

10) ถ้าพบปัญหาทั่วไป และวิธีแก้ด่วน
   - Missing updater.ps1 in install dir: copy updater.ps1 เข้า %LocalAppData%\SUB Estimator แล้วรัน step 5 อีกครั้ง
   - SHA mismatch: สร้าง metadata ใหม่ด้วย create_local_meta.ps1 และอัปโหลด zip+version.json ให้สอดคล้อง
   - Register-ScheduledTask ถูกปฏิเสธ (Access denied): ใช้ schtasks fallback หรือรัน installer เป็น Administrator

11) แล้วทำซ้ำจนผ่านทุกขั้นตอน

ถ้าต้องการ ผมจะ:
- ช่วยอ่าน smoketest_outputs zip ที่คุณส่งมา และระบุจุดที่ต้องแก้ (หากคุณอัปโหลด)
- หรือส่งคำสั่ง debug เพิ่มเติมเฉพาะข้อผิดพลาดที่พบ (paste stdout / updater.log)

# สรุปไฟล์ที่เติม/แก้ไข (สั้น)

ไฟล์ที่ถูกเติมเนื้อหาเพื่อให้ pipeline / updater ทำงานได้แบบปลอดภัย:
- updater.ps1 — wrapper ที่เรียก dist\updater.ps1 (ถ้ามี)
- check_auto_update.ps1 — สคริปต์ทดสอบ updater (ใช้ dist/version.json เป็นค่าเริ่มต้น)
- scripts/run_full_pipeline_and_package.ps1 — Orchestrator (do_everything_local + bundle)
- scripts/check_ready_before_run.ps1 — pre-run checks (zip, version.json, libs)
- scripts/client_quick_install.ps1 — wrapper เรียก install.ps1
- scripts/release_publish_and_sign.ps1 — build-and-publish + best-effort signing
- scripts/collect_and_package_outputs.ps1 — คัดลอกรายงาน smoketest -> dist/smoketest_outputs.zip
- run_all_commands.ps1 — convenience orchestrator
- install-updater-task.ps1 — script ติดตั้ง scheduled task (มี fallback via schtasks XML)
- scripts/finalize_and_check.ps1 — แก้ให้สมบูรณ์และเขียน finalize_summary.txt/.json

หมายเหตุ: โค้ดที่เพิ่ม/แก้เป็นเวอร์ชันเรียบง่ายและปลอดภัย (best-effort). หากต้องการเพิ่มนโยบายเฉพาะ (เช่น overwrite auto, force, silent, sign with specific cert) แจ้งผมได้
