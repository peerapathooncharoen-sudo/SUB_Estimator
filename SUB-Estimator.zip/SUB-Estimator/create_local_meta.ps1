param(
  [string]$ZipPath = 'C:\Users\Admin\Desktop\SUB Estimator\dist\SUB_Estimator_program.zip',
  [string]$Version = '',
  [string]$Owner = 'peerapathooncharoen-sudo',
  [string]$Repo = 'SUB_Estimator',
  [string]$Tag = '',    # if provided, metadata.url will point to GitHub release download for this tag
  [string]$HostUrl = '', # optional: http(s) base URL where dist/ is hosted (e.g. http://localhost/SUB-Estimator/dist)
  [switch]$CopyToXampp,                # when set, copy zip + version.json to XAMPP htdocs
  [string]$XamppPath = 'C:\xampp\htdocs\SUB-Estimator'  # target folder in XAMPP
)
$ErrorActionPreference = 'Stop'

# read version from version.txt if not provided
if ([string]::IsNullOrWhiteSpace($Version)) {
  $vfileCandidate = Join-Path (Split-Path $ZipPath -Parent -ErrorAction SilentlyContinue) '..\version.txt'
  $vfileCandidate = (Resolve-Path $vfileCandidate -ErrorAction SilentlyContinue).Path
  if ($vfileCandidate -and (Test-Path $vfileCandidate)) {
    try { $Version = (Get-Content $vfileCandidate -Raw).Trim() } catch {}
  }
  if (-not $Version) {
    $rootV = Join-Path (Split-Path $PSScriptRoot -Parent) 'version.txt'
    if (Test-Path $rootV) { $Version = (Get-Content $rootV -Raw).Trim() }
  }
  if (-not $Version) { $Version = '0.0.0' }
}

if (-not (Test-Path $ZipPath)) { Write-Error "Zip not found: $ZipPath"; exit 1 }

# compute SHA256
$sha = (Get-FileHash -Algorithm SHA256 -Path $ZipPath -ErrorAction Stop).Hash.ToUpper()

# determine URL: prefer GitHub release if Tag provided,
# otherwise use provided HostUrl (HTTP) if given, else fallback to local file:/// path
if (-not [string]::IsNullOrWhiteSpace($Tag)) {
  $fileUrl = "https://github.com/$Owner/$Repo/releases/download/$Tag/$(Split-Path $ZipPath -Leaf)"
} elseif (-not [string]::IsNullOrWhiteSpace($HostUrl)) {
  # ensure no double slash and append zip filename
  $base = $HostUrl.TrimEnd('/')
  $fileUrl = "$base/" + (Split-Path $ZipPath -Leaf)
} else {
  # local file URL (use absolute path)
  $abs = (Resolve-Path $ZipPath).Path
  $fileUrl = "file:///" + ($abs -replace '\\','/')
}

$metaObj = [ordered]@{
  url     = $fileUrl
  version = $Version
  sha256  = $sha
  date    = (Get-Date).ToString("s")
}

$distMetaPath = Join-Path (Split-Path $ZipPath -Parent) 'version.json'
$rootMetaPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'version.json'

$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath $distMetaPath -Encoding UTF8
Write-Output "Wrote dist meta: $distMetaPath"

$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath $rootMetaPath -Encoding UTF8
Write-Output "Wrote root meta: $rootMetaPath"

# temp copy
$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath (Join-Path $env:TEMP 'sub_meta_local.json') -Encoding UTF8
Write-Output "Wrote meta to: $env:TEMP\sub_meta_local.json"

# --- REPLACE previous "CopyToXampp" block with robust copy logic ---
if ($CopyToXampp -or ($HostUrl -and $HostUrl -match 'localhost')) {
  try {
    $projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
    $distTarget = Join-Path $XamppPath 'dist'

    # Ensure distTarget exists before any further action
    if (-not (Test-Path $distTarget)) { New-Item -ItemType Directory -Path $distTarget -Force | Out-Null }

    # robust web copy: try robocopy (available on modern Windows), otherwise fallback to Copy-Item
    # IMPORTANT: exclude 'dist' so an /MIR mirror doesn't remove the dist folder we prepare
    $excludesDirs = @('.git','dev_tools','scripts','release','node_modules','.github','smoketest_outputs','dist')
    $excludePatterns = @('*.ps1','*.exe','*.zip','*.md','*.psd','*.pdb')

    if (Get-Command robocopy -ErrorAction SilentlyContinue) {
      # Robocopy: mirror web-relevant files but exclude developer dirs and binaries (and dist)
      $robocopyArgs = @(
        $projectRoot,
        $XamppPath,
        '*.*',
        '/MIR',
        '/XD'
      ) + $excludesDirs + @('/XF') + $excludePatterns + @('/R:2','/W:2','/NFL','/NDL')
      & robocopy @robocopyArgs | Out-Null
      Write-Output "Robocopy completed from $projectRoot -> $XamppPath"
    } else {
      # Fallback: copy selected web files and lib folder (won't touch dist)
      $webFiles = @('Index.html','LocalStorage.js','Auth.js','update-notifier.js','DatabasePW.js','DatabaseCT.js','Register.html','login.html','README.md')
      foreach ($f in $webFiles) {
        $src = Join-Path $projectRoot $f
        if (Test-Path $src) {
          Copy-Item -Path $src -Destination (Join-Path $XamppPath $f) -Force -ErrorAction SilentlyContinue
          Write-Output "Copied $f -> $XamppPath"
        }
      }
      # copy lib folder if exists
      $libSrc = Join-Path $projectRoot 'lib'
      if (Test-Path $libSrc) {
        $libDest = Join-Path $XamppPath 'lib'
        Remove-Item -Path $libDest -Recurse -Force -ErrorAction SilentlyContinue
        Copy-Item -Path $libSrc -Destination $libDest -Recurse -Force -ErrorAction SilentlyContinue
        Write-Output "Copied lib/ -> $libDest"
      }
    }

    # Now copy ZIP and version.json into dist (after robocopy so they are preserved)
    $zipName = Split-Path $ZipPath -Leaf
    $destZip = Join-Path $distTarget $zipName
    Copy-Item -Path $ZipPath -Destination $destZip -Force
    Write-Output "Copied ZIP to XAMPP: $destZip"

    $destMeta = Join-Path $distTarget 'version.json'
    Copy-Item -Path $distMetaPath -Destination $destMeta -Force
    Write-Output "Copied dist/version.json to XAMPP: $destMeta"

    # ensure dist folder exists before writing .htaccess (defensive)
    if (-not (Test-Path $distTarget)) { New-Item -ItemType Directory -Path $distTarget -Force | Out-Null }

    # Write .htaccess in dist to allow CORS and disable caching (best-effort)
    $ht = @"
<IfModule mod_headers.c>
  Header set Cache-Control "no-cache, no-store, must-revalidate"
  Header set Pragma "no-cache"
  Header set Expires "0"
  Header set Access-Control-Allow-Origin "*"
  Header set Access-Control-Allow-Methods "GET,OPTIONS"
  Header set Access-Control-Allow-Headers "Content-Type"
</IfModule>
Options -Indexes
"@
    $htPath = Join-Path $distTarget '.htaccess'
    try {
      $ht | Out-File -FilePath $htPath -Encoding UTF8 -Force
      Write-Output "Wrote .htaccess to XAMPP dist: $htPath"
    } catch {
      Write-Warning "Failed to write .htaccess to $htPath : $_"
    }

    # Touch HTML/JS/CSS files in XAMPP to reduce caching issues (update LastWriteTime)
    Get-ChildItem -Path $XamppPath -Include *.html,*.js,*.css -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
      try { $_.LastWriteTime = Get-Date } catch {}
    }
    Write-Output "Touched HTML/JS/CSS files under XAMPP path to reduce caching issues."
  } catch {
    Write-Warning "Failed to copy to XAMPP target $XamppPath : $_"
  }
}
