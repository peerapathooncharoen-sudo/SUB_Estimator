(function(){
  const META_URLS = [ 'dist/version.json', 'version.json' ]; // try server metadata first
  const DISMISS_KEY = 'sub_update_notifier_dismiss_version';

  // NEW: config for silent auto apply + polling + full app scripts
  const CONFIG = {
    AUTO_APPLY: true,                 // อัปเดตอัตโนมัติเมื่อมีเวอร์ชันใหม่
    AUTO_RELOAD_AFTER_APPLY: true,    // รีโหลดหน้าอัตโนมัติหลังอัปเดตสำเร็จ
    ENABLE_POLL: true,                // ตรวจซ้ำเป็นช่วงๆ
    POLL_INTERVAL_MS: 15000,          // ทุก 15 วินาที
    CORE_FILES: [ 'LocalStorage.js', 'Auth.js', 'update-notifier.js' ], // อัปเดตสคริปต์หลักของแอป (นอกเหนือจาก Database*)
    SCAN_PAGE_SCRIPTS: true            // สแกน script[src] ที่โหลดจากโฟลเดอร์โปรเจกต์ เพื่อรวมไฟล์อื่นๆ ที่หน้าเว็บใช้อยู่จริง
  };

  // --- state for diagnostics ---
  const STATE = {
    lastRun: null,
    meta: null,
    metaSourceUrl: null,
    metaTried: META_URLS.slice(),
    localVersion: null,
    remoteVersion: null,
    dismissedVersion: null,
    bannerShown: false,
    bases: null,
    probe: [],
    appliedBase: null,
    applyError: null,
    lastError: null,
    // NEW
    lastAppliedVersion: null
  };

  function log(...args){ try{ console.debug('[update-notifier]', ...args); }catch(e){} }
  function warn(...args){ try{ console.warn('[update-notifier]', ...args); }catch(e){} }
  function getPersist(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
  function setPersist(k,v){ try{ localStorage.setItem(k, v); }catch(e){} }

  function compareVer(a,b){
    const pa = String(a||'0').split('.').map(n=>parseInt(n)||0);
    const pb = String(b||'0').split('.').map(n=>parseInt(n)||0);
    for(let i=0;i<Math.max(pa.length,pb.length);i++){
      const va = pa[i]||0, vb = pb[i]||0;
      if(va>vb) return 1;
      if(va<vb) return -1;
    }
    return 0;
  }

  async function fetchMeta() {
    for (const u of META_URLS) {
      try {
        log('Trying meta URL:', u);
        const r = await fetch(u, { cache:'no-store' });
        if (!r.ok) { log('Not ok:', u, r.status); continue; }
        const txt = await r.text();
        try {
          const j = JSON.parse(txt);
          log('Meta fetched from', u, j);
          STATE.meta = j; STATE.metaSourceUrl = u;
          return j;
        } catch (e) {
          const ver = txt.trim();
          if (ver) {
            log('Found version text at', u, ver);
            const j = { version: ver, url: null, sha256: null };
            STATE.meta = j; STATE.metaSourceUrl = u;
            return j;
          }
        }
      } catch (e) {
        log('Fetch failed for', u, e.message || e);
      }
    }
    warn('No metadata available from candidates:', META_URLS);
    return null;
  }

  // derive candidate base URLs to fetch Database*.js from metadata
  function deriveScriptBases(meta) {
    const bases = [];
    try {
      if (meta && meta.url) {
        const u = String(meta.url);
        const idx = u.indexOf('/dist/');
        if (idx !== -1) bases.push(u.substring(0, idx+1));
        try {
          const metaUrl = new URL(u, location.origin);
          const origin = metaUrl.origin;
          const path = metaUrl.pathname.replace(/\/[^\/]*$/, '/');
          bases.push(origin + path.replace(/\/dist\/?$/, '/'));
        } catch(e){}
      }
    } catch(e){}
    try {
      const origin = location.origin;
      const basePath = location.pathname.replace(/\/[^\/]*$/, '/');
      bases.push(origin + basePath);
    } catch(e){}
    bases.push('./');
    const out = Array.from(new Set(bases.map(b => (b.endsWith('/') ? b : b + '/'))));
    STATE.bases = out.slice();
    return out;
  }

  // NEW: รวมรายชื่อไฟล์ทั้งหมดที่จะอัปเดต (Database + Core + จากหน้า + จาก meta.files)
  function listUpdateTargets(meta) {
    const ordered = [];
    const seen = new Set();

    // 1) Database files (ลำดับก่อน เพื่อให้ฐานข้อมูลพร้อมก่อน)
    ['DatabasePW.js', 'DatabaseCT.js'].forEach(f => { if (!seen.has(f)) { ordered.push(f); seen.add(f); } });

    // 2) Core files กำหนดเอง
    (CONFIG.CORE_FILES || []).forEach(f => {
      if (typeof f === 'string' && f.trim() && !seen.has(f)) { ordered.push(f.trim()); seen.add(f.trim()); }
    });

    // 3) meta.files (ถ้าผู้ดูแลแจกแจงไฟล์ไว้ใน version.json)
    try {
      if (meta && Array.isArray(meta.files)) {
        meta.files.forEach(f => {
          const name = String(f || '').replace(/^\.\//, '');
          if (name && name.endsWith('.js') && !seen.has(name)) { ordered.push(name); seen.add(name); }
        });
      }
    } catch(e){}

    // 4) สแกน script[src] ในหน้า (เฉพาะไฟล์ที่อยู่ในโฟลเดอร์โปรเจกต์เดียวกันและเป็น same-origin)
    try {
      if (CONFIG.SCAN_PAGE_SCRIPTS && document && document.querySelectorAll) {
        const basePath = location.pathname.replace(/\/[^\/]*$/, '/'); // โฟลเดอร์ของ Index.html
        document.querySelectorAll('script[src]').forEach(s => {
          try {
            const u = new URL(s.getAttribute('src'), location.href);
            if (u.origin !== location.origin) return;        // ข้าม CDN/ต่าง origin
            if (!u.pathname.startsWith(basePath)) return;    // เอาเฉพาะในโฟลเดอร์โปรเจกต์
            const rel = u.pathname.substring(basePath.length).replace(/^\/+/, ''); // path ภายในโปรเจกต์
            if (rel && rel.endsWith('.js') && !seen.has(rel)) {
              ordered.push(rel);
              seen.add(rel);
            }
          } catch(e){}
        });
      }
    } catch(e){}

    return ordered;
  }

  // attempt to fetch a file URL (returns true if ok)
  async function probeUrl(url) {
    try {
      const r = await fetch(url, { method:'HEAD', cache:'no-store' });
      if (r && r.ok) return true;
      const r2 = await fetch(url, { cache:'no-store' });
      return r2 && r2.ok;
    } catch (e) { return false; }
  }

  // inject script tag (removes existing tags that match filename)
  function injectScriptWithBuster(srcUrl) {
    const fname = srcUrl.replace(/.*\/([^\/\?]+)(\?.*)?$/, '$1');
    Array.from(document.querySelectorAll('script[src]')).forEach(s => {
      try {
        const sname = s.getAttribute('src') || '';
        if (sname.indexOf('/' + fname) !== -1 || sname === fname || s.src.indexOf('/' + fname) !== -1) {
          s.parentNode.removeChild(s);
        }
      } catch(e){}
    });
    const s = document.createElement('script');
    s.src = srcUrl;
    s.async = false;
    s.defer = false;
    document.head.appendChild(s);
    return new Promise((resolve, reject) => {
      s.onload = () => resolve(true);
      s.onerror = () => reject(new Error('load failed: ' + srcUrl));
    });
  }

  // UPDATED: apply web update สำหรับ "ทุกไฟล์" ที่หน้าใช้งาน ไม่ใช่แค่ Database
  async function applyWebUpdate(meta, opts) {
    if (!meta) {
      if (!opts || !opts.silent) alert('ไม่มี metadata สำหรับอัพเดต');
      return;
    }
    STATE.applyError = null; STATE.appliedBase = null; STATE.probe = [];
    const ver = meta.version || String(Date.now());
    const bases = deriveScriptBases(meta);
    const files = listUpdateTargets(meta); // << ใช้รายการไฟล์ทั้งหมด
    if (!files || files.length === 0) {
      if (!opts || !opts.silent) alert('ไม่พบไฟล์สคริปต์ที่จะอัปเดต');
      return;
    }

    const succeeded = [];
    for (const base of bases) {
      let allOk = true;
      // ตรวจสอบว่าฐานนี้มีไฟล์ครบ
      for (const f of files) {
        const candidate = base + f + '?v=' + encodeURIComponent(ver);
        try {
          const ok = await probeUrl(candidate.split('?')[0]);
          try { STATE.probe.push({ url: candidate.split('?')[0], ok }); } catch(e){}
          if (!ok) { allOk = false; break; }
        } catch(e) { allOk = false; break; }
      }
      if (!allOk) continue;

      // โหลดทับทีละไฟล์ตามลำดับ
      try {
        for (const f of files) {
          const url = base + f + '?v=' + encodeURIComponent(ver);
          await injectScriptWithBuster(url);
        }
        succeeded.push(base);
        STATE.appliedBase = base;
        break;
      } catch (e) {
        STATE.applyError = (e && e.message) ? e.message : String(e);
        // ลองฐานถัดไป
      }
    }

    if (succeeded.length === 0) {
      if (!opts || !opts.silent) alert('ไม่สามารถดาวน์โหลดสคริปต์อัปเดตจากเซิร์ฟเวอร์ได้. ตรวจเมตาดาต้า/เส้นทางไฟล์ในเซิร์ฟเวอร์');
      return;
    }

    // re-init เบาๆ เผื่อมี hook
    try { if (typeof renderSavedList === 'function') renderSavedList(); } catch(e){}
    try { if (typeof updateSummary === 'function') updateSummary(); } catch(e){}
    try {
      if (typeof addRow === 'function') {
        const pb=document.getElementById('power-table-body'); const cb=document.getElementById('control-table-body');
        if(pb && pb.children.length===0) addRow('power');
        if(cb && cb.children.length===0) addRow('control');
      }
    } catch(e){}

    if (opts && opts.silent) return;
    if (confirm('อัปเดตสคริปต์เสร็จแล้ว ต้องการรีโหลดหน้าเพื่อให้การเปลี่ยนแปลงทั้งหมดมีผลหรือไม่?')) {
      location.reload();
    } else {
      alert('อัปเดตสคริปต์เสร็จแล้ว — หากส่วนอื่นยังไม่เปลี่ยน ลองรีโหลดหน้าเมื่อพร้อม');
    }
  }

  function showBanner(version, url, meta) {
    if (!document || document.getElementById('sub-update-banner')) return;
    STATE.bannerShown = true;
    const banner = document.createElement('div');
    banner.id = 'sub-update-banner';
    Object.assign(banner.style, { position:'fixed', right:'16px', bottom:'16px', zIndex:2147483647, background:'#fff3cd', color:'#222', border:'1px solid #ffeeba', padding:'12px 14px', borderRadius:'6px', boxShadow:'0 6px 18px rgba(0,0,0,0.12)', fontSize:'13px', maxWidth:'420px' });
    banner.innerHTML = `<div style="margin-bottom:8px"><strong>มีอัปเดตใหม่:</strong> เวอร์ชัน ${escapeHtml(version)} พร้อมให้ดาวน์โหลด</div>`;
    const btnUpdate = document.createElement('button'); btnUpdate.textContent = 'อัปเดตตอนนี้'; btnUpdate.style.marginRight='8px';
    btnUpdate.onclick = function(){ try{ window.open(url || '','_blank'); } catch(e){ if(url) location.href = url; } };
    const btnApplyWeb = document.createElement('button'); btnApplyWeb.textContent = 'Apply web update'; btnApplyWeb.style.marginRight='8px';
    btnApplyWeb.onclick = function(){ try { applyWebUpdate(meta); } catch(e){ console.error(e); alert('Apply failed: '+(e && e.message?e.message:e)); } };
    const btnRemind = document.createElement('button'); btnRemind.textContent = 'เตือนทีหลัง'; btnRemind.style.marginRight='8px';
    btnRemind.onclick = function(){ localStorage.setItem(DISMISS_KEY, version); banner.remove(); };
    const btnClose = document.createElement('button'); btnClose.textContent = 'ปิด';
    btnClose.onclick = function(){ banner.remove(); };
    const actions = document.createElement('div'); actions.style.marginTop='8px';
    actions.appendChild(btnUpdate); actions.appendChild(btnApplyWeb); actions.appendChild(btnRemind); actions.appendChild(btnClose);
    banner.appendChild(actions); document.body.appendChild(banner);
  }

  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  async function run(){
    try {
      STATE.lastRun = new Date().toISOString();
      const meta = await fetchMeta();
      if (!meta) { log('No meta, abort notifier.'); return; }
      const remoteVer = meta.version ? String(meta.version) : null;
      const remoteUrl = meta.url ? String(meta.url) : (meta.url || 'dist/SUB_Estimator_program.zip');
      STATE.remoteVersion = remoteVer;
      if (!remoteVer) { log('Remote version missing in meta'); return; }
      let localVer = '0.0.0';
      try { const r = await fetch('version.txt', { cache:'no-store' }); if (r.ok) { localVer = (await r.text()).trim() || localVer; } } catch(e){}
      try { const inst = localStorage.getItem('sub_installed_version'); if (inst) localVer = inst; } catch(e){}
      STATE.localVersion = localVer;

      const cmp = compareVer(remoteVer, localVer);
      const dismissed = localStorage.getItem(DISMISS_KEY);
      STATE.dismissedVersion = dismissed || null;

      // NEW: prevent repeated auto-apply
      STATE.lastAppliedVersion = getPersist('sub_last_applied_version');

      if (cmp > 0) {
        // มีเวอร์ชันใหม่
        if (CONFIG.AUTO_APPLY) {
          if (STATE.lastAppliedVersion === remoteVer) {
            log('Already auto-applied this version earlier:', remoteVer);
            return;
          }
          log('Auto applying update to version', remoteVer);
          await applyWebUpdate(meta, { silent: true });
          setPersist('sub_last_applied_version', remoteVer);
          if (CONFIG.AUTO_RELOAD_AFTER_APPLY) {
            // รีโหลดเพื่อให้ Index/สคริปต์อื่นๆ โหลดเวอร์ชันใหม่ด้วย
            location.reload();
          }
          return;
        }
        // แสดงแบนเนอร์ในกรณีไม่ได้เปิด AUTO_APPLY
        if (!(dismissed && dismissed === remoteVer)) {
          showBanner(remoteVer, remoteUrl, meta);
        }
      } else {
        log('No newer version');
      }
    } catch (e) {
      STATE.lastError = e && e.message ? e.message : String(e);
      warn('update-notifier run error', STATE.lastError);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ()=>setTimeout(run,300));
  } else { setTimeout(run,300); }

  // background polling
  if (CONFIG.ENABLE_POLL) {
    try { setInterval(() => { try { run(); } catch(e){} }, Math.max(5000, CONFIG.POLL_INTERVAL_MS|0)); } catch(e){}
  }

  // expose minimal API
  try {
    window.getUpdateStatus = function(){
      try {
        const pw = document.querySelector('script[src*="DatabasePW.js"]');
        const ct = document.querySelector('script[src*="DatabaseCT.js"]');
        const scripts = { DatabasePW: pw ? pw.getAttribute('src') : null, DatabaseCT: ct ? ct.getAttribute('src') : null };
        return { ...STATE, scripts };
      } catch(e){ return { ...STATE }; }
    };
    window.runUpdateNotifier = run;
    window.applyWebUpdateNow = function(){ try { return applyWebUpdate(STATE.meta || null); } catch(e){ alert(e && e.message ? e.message : e); } };
  } catch(e){}
})();
