Set-Location 'C:\Users\Admin\Desktop\SUB Estimator'

# basic env
Get-Location
whoami

# dist / metadata / zip
Get-ChildItem .\dist | Format-Table Name,Length
Get-Content .\dist\version.json -Raw
Get-FileHash -Algorithm SHA256 .\dist\SUB_Estimator_program.zip

# installed updater files
Test-Path "$env:LOCALAPPDATA\SUB Estimator\updater.ps1"
Get-ChildItem "$env:LOCALAPPDATA\SUB Estimator" -Recurse -Force | Select-Object FullName,Length

# scheduled task status
schtasks /Query /TN "SUB Estimator Updater" /V /FO LIST 2>&1
# (if not found)
schtasks /Query /V /FO LIST | Select-String -Pattern "SUB Estimator" -Context 0,3

# run updater manually (use local metadata)
$meta = (Resolve-Path .\dist\version.json).Path
$uri = "file:///"+($meta -replace '\\','/')
powershell -NoProfile -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\SUB Estimator\updater.ps1" -MetaUrl $uri 2>&1 | Tee-Object .\smoketest_outputs\updater_stdout.txt

# logs
Get-Content "$env:LOCALAPPDATA\SUB Estimator\updater.log" -Tail 200 -ErrorAction SilentlyContinue
Get-Content .\smoketest_outputs\updater_stdout.txt -ErrorAction SilentlyContinue

Param(
  [string]$MetaUrl = '',
  [string]$InstallDir = "$env:TEMP\sub_update_test"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not $MetaUrl) {
  $meta = Join-Path (Get-Location).Path 'dist\version.json'
  if (Test-Path $meta) { $MetaUrl = "file:///" + ((Resolve-Path $meta).Path -replace '\\','/') } else { Write-Error "No MetaUrl provided and dist\version.json missing."; exit 1 }
}

Write-Host "Running updater test with MetaUrl: $MetaUrl"
$updater = Join-Path (Get-Location).Path 'updater.ps1'
if (-not (Test-Path $updater)) { Write-Error "updater.ps1 not found at $updater"; exit 1 }

if (Test-Path $InstallDir) { Remove-Item -Recurse -Force $InstallDir -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $InstallDir | Out-Null

& powershell -NoProfile -ExecutionPolicy Bypass -File $updater -MetaUrl $MetaUrl -InstallDir $InstallDir
Write-Host "Updater test finished. InstallDir used: $InstallDir"
& powershell -NoProfile -ExecutionPolicy Bypass -File $updater -MetaUrl $MetaUrl -InstallDir $InstallDir
Write-Host "Updater test finished. Files placed in: $InstallDir"
