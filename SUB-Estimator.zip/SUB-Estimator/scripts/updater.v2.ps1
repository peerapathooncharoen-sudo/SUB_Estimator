﻿param([string]$Source = "")
$ErrorActionPreference = "Stop"

function Get-AppRoot { Split-Path -Parent $PSCommandPath }
function Read-Version($path) {
  if (Test-Path $path) {
    try {
      $j = Get-Content -Raw -Path $path | ConvertFrom-Json
      foreach ($k in @('version','Version','appVersion')) { if ($j.PSObject.Properties.Name -contains $k) { return [string]$j.$k } }
    } catch {}
  }
  $txt = Join-Path (Split-Path $path) "version.txt"
  if (Test-Path $txt) { return (Get-Content -Raw $txt).Trim() }
  return ""
}
function IsNewer($a,$b) { try { [version]$a -gt [version]$b } catch { $a -ne $b } }

$app = Get-AppRoot
$logDir = Join-Path $app "logs"; if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$log = Join-Path $logDir "updater.log"
function Log($m){ ("[{0}] {1}" -f (Get-Date).ToString("s"), $m) | Add-Content -Path $log }

if ([string]::IsNullOrWhiteSpace($Source)) {
  $cfg = Join-Path $PSScriptRoot "update.config.json"
  if (Test-Path $cfg) { $Source = (Get-Content -Raw $cfg | ConvertFrom-Json).Source }
}

try {
  Log "Start update. Source=$Source"
  if ([string]::IsNullOrWhiteSpace($Source)) { Log "No Source provided."; exit 0 }
  if (-not (Test-Path $Source)) { Log "Source not reachable: $Source"; exit 0 }

  $localVer = Read-Version (Join-Path $app "version.json")
  $remoteVerPath = Join-Path $Source "version.json"
  if (-not (Test-Path $remoteVerPath)) { Log "Missing remote version.json"; exit 0 }
  $remoteVer = Read-Version $remoteVerPath

  if (-not (IsNewer $remoteVer $localVer)) { Log "Already up to date ($localVer)."; exit 0 }

  $pkg = "SUB_Estimator_Distribution.zip"
  try {
    $j = Get-Content -Raw -Path $remoteVerPath | ConvertFrom-Json
    foreach ($k in @('package','zip','artifact')) { if ($j.PSObject.Properties.Name -contains $k) { $pkg = [string]$j.$k; break } }
  } catch {}
  $remoteZip = Join-Path $Source $pkg
  if (-not (Test-Path $remoteZip)) { Log "Package not found: $remoteZip"; exit 0 }

  $temp = Join-Path $env:TEMP ("SUB_Upd_" + [guid]::NewGuid().ToString("N"))
  $newDir = Join-Path $temp "new"
  New-Item -ItemType Directory -Path $newDir -Force | Out-Null

  Copy-Item $remoteZip (Join-Path $temp $pkg) -Force
  Expand-Archive -Path (Join-Path $temp $pkg) -DestinationPath $newDir -Force

  $exclude = @("release","scripts","smoketest_outputs","logs")
  Get-ChildItem $newDir -Force | ForEach-Object {
    if ($exclude -contains $_.Name) { return }
    Copy-Item $_.FullName (Join-Path $app $_.Name) -Recurse -Force
  }

  Copy-Item (Join-Path $Source "version.json") (Join-Path $app "version.json") -Force
  if (Test-Path (Join-Path $Source "version.txt")) { Copy-Item (Join-Path $Source "version.txt") (Join-Path $app "version.txt") -Force }
  Log "Updated to $remoteVer"
} catch {
  Log "Error: $($_.Exception.Message)"
  exit 1
}
