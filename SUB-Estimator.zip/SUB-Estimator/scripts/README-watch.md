Local automatic build (PowerShell)

1. Open PowerShell in the project root.
2. Run: powershell -ExecutionPolicy Bypass -File .\scripts\watch-and-build.ps1
3. The script watches for changes and runs `scripts\build_clean_zip.ps1` after you stop editing for ~800ms.

CI (GitHub Actions)

- A workflow is added at `.github/workflows/auto-build-zip.yml`.
- On push to `main` or manual run it will build the `dist/SUB_Estimator_CleanRelease.zip` and push it back to `main` and upload it as an artifact.
- To use CI: push your changes to `main` or trigger the workflow from the Actions tab.
