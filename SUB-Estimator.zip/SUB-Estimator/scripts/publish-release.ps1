﻿param(
  [Parameter(Mandatory=$true)][string]$Version,
  [string]$PackageName = "SUB_Estimator_Distribution.zip",
  [string]$DistPath = "$PSScriptRoot\..\dist",
  [string]$ReleasePath = "$PSScriptRoot\..\release"
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Resolve-Path "$PSScriptRoot\..")
if (-not (Test-Path $ReleasePath)) { New-Item -ItemType Directory -Path $ReleasePath | Out-Null }
$zipPath = Join-Path $ReleasePath $PackageName

if (Test-Path $DistPath -PathType Container -and (Get-ChildItem $DistPath -Recurse -Force | Measure-Object).Count -gt 0) {
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
  Compress-Archive -Path (Join-Path $DistPath '*') -DestinationPath $zipPath -Force
} else {
  $exclude = @('release','scripts','smoketest_outputs','dev_tools','.git','.github','node_modules')
  $items = Get-ChildItem $root -Force | Where-Object { $exclude -notcontains $_.Name }
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
  Compress-Archive -Path $items.FullName -DestinationPath $zipPath -Force
}

$verObj = [ordered]@{
  version = $Version
  package = $PackageName
  date    = (Get-Date).ToString("s")
}
$verPath = Join-Path $ReleasePath "version.json"
$verObj | ConvertTo-Json -Depth 5 | Set-Content -Path $verPath -Encoding UTF8
Write-Host "Published $zipPath"
Write-Host "Wrote $verPath"
