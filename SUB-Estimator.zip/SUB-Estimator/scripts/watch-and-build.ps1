<#
Simple PowerShell FileSystemWatcher that runs build_clean_zip.ps1 when files under the project change.
Usage: .\watch-and-build.ps1
#>

param(
    [string]$Path = (Get-Location).Path,
    [string]$BuildScript = "scripts\build_clean_zip.ps1",
    [int]$DebounceMs = 800
)

Write-Host "Watching path: $Path" -ForegroundColor Cyan

$fsw = New-Object System.IO.FileSystemWatcher $Path -Property @{ IncludeSubdirectories = $true; NotifyFilter = [System.IO.NotifyFilters]'FileName, LastWrite, DirectoryName' }

$timer = New-Object System.Timers.Timer
$timer.AutoReset = $false
$timer.Interval = $DebounceMs
$pending = $false

Register-ObjectEvent $fsw Changed -SourceIdentifier FileChanged -Action {
    $global:pending = $true
    $timer.Stop()
    $timer.Start()
}
Register-ObjectEvent $fsw Created -SourceIdentifier FileCreated -Action {
    $global:pending = $true
    $timer.Stop()
    $timer.Start()
}
Register-ObjectEvent $fsw Renamed -SourceIdentifier FileRenamed -Action {
    $global:pending = $true
    $timer.Stop()
    $timer.Start()
}

$timerEvent = Register-ObjectEvent $timer Elapsed -SourceIdentifier Debounced -Action {
    if ($global:pending) {
        $global:pending = $false
        Write-Host "Change detected — running build script..." -ForegroundColor Yellow
        try {
            if (Test-Path $BuildScript) {
                & $BuildScript -OutDir "dist"
            } else {
                Write-Host "Build script not found: $BuildScript" -ForegroundColor Red
            }
        } catch {
            Write-Host "Build failed: $_" -ForegroundColor Red
        }
    }
}

$fsw.EnableRaisingEvents = $true
Write-Host "Press Enter to stop watching." -ForegroundColor Green
[Console]::ReadLine() | Out-Null

# cleanup
Unregister-Event -SourceIdentifier FileChanged -ErrorAction SilentlyContinue
Unregister-Event -SourceIdentifier FileCreated -ErrorAction SilentlyContinue
Unregister-Event -SourceIdentifier FileRenamed -ErrorAction SilentlyContinue
Unregister-Event -SourceIdentifier Debounced -ErrorAction SilentlyContinue
$fsw.Dispose()
$timer.Dispose()
Write-Host "Stopped." -ForegroundColor Cyan
