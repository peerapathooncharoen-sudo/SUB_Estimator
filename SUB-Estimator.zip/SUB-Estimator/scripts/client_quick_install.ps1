Param(
  [string]$SourceZip = '.\dist\SUB_Estimator_program.zip',
  [switch]$RegisterUpdater
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptROOT).Path
$installScript = Join-Path $scriptRoot '..\install.ps1'

if (-not (Test-Path $SourceZip)) { Write-Error "Source zip not found: $SourceZip"; exit 1 }

if (Test-Path $installScript) {
  $args = @('-SourceZip', $SourceZip)
  if ($RegisterUpdater) { $args += '-RegisterUpdater' }
  & powershell -NoProfile -ExecutionPolicy Bypass -File $installScript @args
} else {
  Write-Error "install.ps1 not found: $installScript"
  exit 1
}
Write-Host "Extracting $zipFull -> $InstallDir"
try { Expand-Archive -Path $zipFull -DestinationPath $InstallDir -Force } catch { Write-Error "Extract failed: $_"; exit 1 }

# determine meta url if not provided (use local version.json inside extracted dist or InstallDir)
if ([string]::IsNullOrWhiteSpace($MetaUrl)) {
  $candidate = Join-Path $ProjectRoot 'dist\version.json'
  if (-not (Test-Path $candidate)) { $candidate = Join-Path $InstallDir 'version.json' }
  if (Test-Path $candidate) {
    $abs = (Resolve-Path $candidate).Path
    $MetaUrl = "file:///" + ($abs -replace '\\','/')
  } else {
    Write-Warning "No version.json found to build MetaUrl; installer will be invoked without -MetaUrl"
  }
}
Write-Host "MetaUrl: $MetaUrl"

# ensure updater/updater installer exist
$installerScript = Join-Path $InstallDir 'install-updater-task.ps1'
$updaterScript   = Join-Path $InstallDir 'updater.ps1'
if (-not (Test-Path $installerScript)) { Write-Warning "install-updater-task.ps1 not found at $installerScript" }
if (-not (Test-Path $updaterScript))   { Write-Warning "updater.ps1 not found at $updaterScript" }

# Run installer script (use bypass ExecutionPolicy)
try {
  if (Test-Path $installerScript) {
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$installerScript)
    if ($MetaUrl) { $args += @('-MetaUrl',$MetaUrl) }
    Write-Host "Invoking install-updater-task.ps1 ..."
    Start-Process -FilePath 'powershell.exe' -ArgumentList $args -NoNewWindow -Wait
    Write-Host "install-updater-task.ps1 completed."
  } else {
    Write-Warning "Skipping install-updater-task.ps1 (missing)."
  }
} catch {
  Write-Warning "Installer invocation failed: $_"
}

# safe schtasks query (capture output)
$taskName = "SUB Estimator Updater"
$schtOut = Join-Path $ProjectRoot 'client_quick_install_schtasks.txt'
Write-Host "Query schtasks -> $schtOut"
try {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = "schtasks.exe"
  $psi.Arguments = "/Query /TN `"$taskName`" /V /FO LIST"
  $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
  $p = New-Object System.Diagnostics.Process; $p.StartInfo = $psi
  if ($p.Start()) {
    $out = $p.StandardOutput.ReadToEnd(); $err = $p.StandardError.ReadToEnd(); $p.WaitForExit()
    ($out + "`n" + $err).Trim() | Out-File -FilePath $schtOut -Encoding UTF8
    if ($p.ExitCode -ne 0) { Write-Warning "schtasks returned code $($p.ExitCode). See $schtOut" } else { Write-Host "schtasks OK. See $schtOut" }
  } else { Write-Warning "Failed to run schtasks.exe" }
} catch { Write-Warning "schtasks check failed: $_" }

# Run updater manually (test)
$upStdOut = Join-Path $ProjectRoot 'client_quick_install_updater_stdout.txt'
if (Test-Path $updaterScript) {
  try {
    $uArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$updaterScript)
    if ($MetaUrl) { $uArgs += @('-MetaUrl',$MetaUrl) }
    Write-Host "Running updater (manual test)..."
    Start-Process -FilePath 'powershell.exe' -ArgumentList $uArgs -NoNewWindow -Wait -PassThru | Out-Null
    # capture log if present
    $log = Join-Path $InstallDir 'updater.log'
    if (Test-Path $log) {
      Copy-Item -Path $log -Destination (Join-Path $ProjectRoot 'client_updater.log') -Force
      Write-Host "Copied updater.log -> client_updater.log"
    }
    Write-Host "Updater manual run completed."
  } catch {
    Write-Warning "Updater run failed: $_"
  }
} else {
  Write-Warning "Updater script missing; skipping manual run."
}

# final summary
Write-Host "==== SUMMARY ===="
if (Test-Path $schtOut) { Get-Content $schtOut | Write-Host }
if (Test-Path (Join-Path $ProjectRoot 'client_updater.log')) {
  Write-Host "`n--- updater.log (tail 80) ---"
  Get-Content (Join-Path $ProjectRoot 'client_updater.log') -Tail 80 | Write-Host
}
Write-Host "`nClient quick install finished. Files created in project root: client_quick_install_schtasks.txt, client_updater.log (if present)."
