﻿param(
  [string]$Action = "inspect", # inspect | publish | install-task
  [string]$ReleasePath = "$PSScriptRoot\..\release",
  [string]$ShareName = "SUBEstimatorUpdates",
  [Parameter(Mandatory=$false)][string]$Version = "",
  [string]$PackageName = "SUB_Estimator_program.zip",
  [string]$DistPath = "$PSScriptRoot\..\dist",
  [string]$Source = "",   # used by install-task: path or UNC to version.json root
  [string]$TaskName = "SUB Estimator Updater"
)
$ErrorActionPreference = "Stop"

function Resolve-Paths {
  try { $scriptRoot = (Resolve-Path $PSScriptRoot -ErrorAction SilentlyContinue).Path } catch { $scriptRoot = $PSScriptRoot }
  $projectRoot = (Join-Path $scriptRoot "..") | Resolve-Path -ErrorAction SilentlyContinue
  if ($projectRoot) { $projectRoot = $projectRoot.Path } else { $projectRoot = (Split-Path -Parent $scriptRoot) }
  $global:ScriptRoot = $scriptRoot
  $global:ProjectRoot = $projectRoot

  $rp = Resolve-Path -Path $ReleasePath -ErrorAction SilentlyContinue
  if ($rp) { $global:ReleasePath = $rp.Path } else { $global:ReleasePath = $ReleasePath }
  if (-not (Test-Path $global:ReleasePath)) { New-Item -ItemType Directory -Path $global:ReleasePath | Out-Null }
}
Resolve-Paths

function Inspect-ProjectFolder {
  param([string]$ProjectRootParam = $ProjectRoot)
  $releasePath = Join-Path $ProjectRootParam "release"
  $distPath    = Join-Path $ProjectRootParam "dist"
  $scriptsPath = Join-Path $ProjectRootParam "scripts"
  $cfgPath     = Join-Path $scriptsPath "update.config.json"

  $rExists = Test-Path $releasePath
  $dExists = Test-Path $distPath
  $sExists = Test-Path $scriptsPath
  $cfgExists = Test-Path $cfgPath

  $releaseFiles = if ($rExists) { (Get-ChildItem -Path $releasePath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count } else { 0 }
  $distFiles    = if ($dExists) { (Get-ChildItem -Path $distPath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count } else { 0 }
  $zipsInRelease = if ($rExists) { Get-ChildItem -Path $releasePath -Filter *.zip -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name -ErrorAction SilentlyContinue } else { @() }

  try { schtasks /Query /TN "$TaskName" > $null 2>&1; $taskInstalled = ($LASTEXITCODE -eq 0) } catch { $taskInstalled = $false }
  try { Get-SmbShare -Name $ShareName -ErrorAction Stop | Out-Null; $shareExists = $true } catch { $shareExists = $false }

  Write-Host "Project root: $ProjectRootParam"
  Write-Host " - release: $([bool]$rExists) (files: $releaseFiles)"
  if ($zipsInRelease.Count -gt 0) { Write-Host "   - zip in release: $($zipsInRelease -join ', ')" }
  Write-Host " - dist: $([bool]$dExists) (files: $distFiles)"
  Write-Host " - scripts: $([bool]$sExists)"
  Write-Host " - update.config.json: $([bool]$cfgExists)"
  Write-Host " - scheduled task '$TaskName' installed: $([bool]$taskInstalled)"
  Write-Host " - SMB share '$ShareName' exists: $([bool]$shareExists)"
  Write-Host ""
  Write-Host "Usage examples:"
  Write-Host " - Inspect:    powershell -NoProfile -File .\setup-release-share.ps1 -Action inspect"
  Write-Host " - Publish:    powershell -NoProfile -File .\setup-release-share.ps1 -Action publish -Version 1.2.0"
  Write-Host " - Install-task (on client or admin machine):"
  Write-Host "     powershell -NoProfile -File .\setup-release-share.ps1 -Action install-task -Source '\\\\server\\Share' "
}

function Create-ZipAndMeta {
  param([string]$VersionParam)
  $distFull = (Resolve-Path -Path $DistPath -ErrorAction SilentlyContinue)
  if ($distFull) { $distFull = $distFull.Path } else { New-Item -ItemType Directory -Path $DistPath | Out-Null; $distFull = (Resolve-Path $DistPath).Path }

  $zipPath = Join-Path $ReleasePath $PackageName
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force -ErrorAction SilentlyContinue }

  if ((Test-Path $DistPath) -and ((Get-ChildItem -Path $DistPath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0)) {
    Compress-Archive -Path (Join-Path $DistPath '*') -DestinationPath $zipPath -Force
  } else {
    $exclude = @('release','scripts','smoketest_outputs','dev_tools','.git','.github','node_modules')
    $items = Get-ChildItem -Path $ProjectRoot -Force | Where-Object { $exclude -notcontains $_.Name }
    Compress-Archive -Path ($items | ForEach-Object { $_.FullName }) -DestinationPath $zipPath -Force
  }

  if (Test-Path $zipPath) { $sha = (Get-FileHash -Algorithm SHA256 -Path $zipPath -ErrorAction Stop).Hash.ToUpper() } else { $sha = "" }

  $fileUrl = "file:///" + (Join-Path ("\\$($env:COMPUTERNAME)\$ShareName") $PackageName) -replace '\\','/'

  if (-not [string]::IsNullOrWhiteSpace($VersionParam)) { $ver = $VersionParam } else {
    $vfile = Join-Path $ProjectRoot 'version.txt'
    if (Test-Path $vfile) { $ver = (Get-Content $vfile -Raw).Trim() } else { $ver = '' }
  }

  $verObj = [ordered]@{
    url     = $fileUrl
    version = $ver
    sha256  = $sha
    date    = (Get-Date).ToString("s")
  }
  $verPath = Join-Path $ReleasePath "version.json"
  $verObj | ConvertTo-Json -Depth 5 | Set-Content -Path $verPath -Encoding UTF8
  Write-Host "Created package: $zipPath"
  Write-Host "Wrote version.json: $verPath (sha256: $sha)"
}

function Ensure-SmbShare {
  param([string]$PathToShare)
  try {
    if (-not (Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue)) {
      New-SmbShare -Name $ShareName -Path $PathToShare -ReadAccess "Authenticated Users" | Out-Null
      Write-Host "SMB share '$ShareName' created -> $PathToShare"
    } else {
      Write-Host "SMB share '$ShareName' already exists"
    }
  } catch {
    Write-Warning "Unable to create SMB share (requires admin). Error: $_"
  }
}

function Install-UpdaterTask {
  param([string]$SourceParam)
  if ([string]::IsNullOrWhiteSpace($SourceParam)) { Write-Warning "Source (UNC or local path to release) required to install task"; return }
  $configPath = Join-Path $ProjectRoot "scripts\update.config.json"
  @{ Source = $SourceParam } | ConvertTo-Json -Depth 2 | Set-Content -Path $configPath -Encoding UTF8

  try { schtasks /Query /TN "$TaskName" > $null 2>&1 ; if ($LASTEXITCODE -eq 0) { schtasks /Delete /TN "$TaskName" /F > $null 2>&1 } } catch {}

  $updater = Join-Path $ProjectRoot "updater.ps1"
  if (-not (Test-Path $updater)) { Write-Warning "updater.ps1 not found at $updater; ensure updater exists in project root"; return }

  $arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updater`" -MetaUrl `"$SourceParam/version.json`""
  try {
    $action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument $arg
    $trLogon = New-ScheduledTaskTrigger -AtLogOn
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trLogon -RunLevel Highest -Force | Out-Null
    Write-Host "Registered scheduled task '$TaskName' (AtLogOn)."
  } catch {
    Write-Warning "Register-ScheduledTask failed or insufficient privileges. Falling back to schtasks.exe create (per-user)."
    try {
      $trRaw = "PowerShell.exe $arg"
      $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Author>$($env:USERNAME)</Author></RegistrationInfo>
  <Triggers><LogonTrigger><Enabled>true</Enabled></LogonTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>$($env:USERNAME)</UserId><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings><StartWhenAvailable>true</StartWhenAvailable><Enabled>true</Enabled></Settings>
  <Actions Context="Author"><Exec><Command>PowerShell.exe</Command><Arguments><![CDATA[$trRaw]]></Arguments></Exec></Actions>
</Task>
"@
      $xmlPath = Join-Path $env:TEMP ("sub_task_{0}.xml" -f ([guid]::NewGuid().ToString("N")))
      $xml | Out-File -FilePath $xmlPath -Encoding Unicode
      Start-Process -FilePath "schtasks.exe" -ArgumentList "/Create","/TN",$TaskName,"/XML",$xmlPath,"/F" -NoNewWindow -Wait -ErrorAction Stop
      Write-Host "Created scheduled task via schtasks.exe (ONLOGON using XML)."
      Remove-Item -Path $xmlPath -ErrorAction SilentlyContinue
    } catch {
      Write-Error "Fallback schtasks.exe failed: $_"
    }
  }
}

switch ($Action.ToLower()) {
  'inspect' { Inspect-ProjectFolder; break }
  'publish' {
    Create-ZipAndMeta -VersionParam $Version
    Ensure-SmbShare -PathToShare $ReleasePath
    break
  }
  'install-task' {
    if ([string]::IsNullOrWhiteSpace($Source)) { Write-Error "When Action=install-task, provide -Source (UNC or path to release root)"; break }
    Install-UpdaterTask -SourceParam $Source
    break
  }
  default { Write-Error "Unknown Action: $Action. Supported: inspect | publish | install-task" }
}

