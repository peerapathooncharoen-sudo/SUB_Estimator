# Run the safe removal script non-interactively (use only if you approved deletion).
# This script calls remove_dev_tools_and_ci.ps1 with -Force and captures console output to a log.

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Resolve paths robustly
$scriptRoot = (Resolve-Path $PSScriptRoot).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path
$removeScript = Join-Path $projectRoot 'remove_dev_tools_and_ci.ps1'
$logDir = Join-Path $projectRoot 'scripts'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$log = Join-Path $logDir ("run_remove_dev_tools_and_ci_now_$ts.log")

if (-not (Test-Path $removeScript)) { Write-Error "remove_dev_tools_and_ci.ps1 not found: $removeScript"; exit 1 }

Write-Host "Launching removal (non-interactive, -Force). Backup will be created by the removal script."
Write-Host "Log file: $log"

try {
  $cmd = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $removeScript, '-Force')
  Write-Host "Running: powershell $($cmd -join ' ')"
  # capture combined output to console and log
  & powershell @cmd 2>&1 | Tee-Object -FilePath $log
  $exit = $LASTEXITCODE

  if ($exit -eq 0) {
    Write-Host "Removal script finished successfully. See log: $log"
  } else {
    Write-Error "Removal failed (exit code $exit). See log: $log"
    exit $exit
  }
} catch {
  $_ | Out-File -FilePath $log -Append -Encoding UTF8
  Write-Error "Removal invocation failed. See log: $log"
  exit 1
}
  $_ | Out-File -FilePath $log -Append -Encoding UTF8
  Write-Error "Removal invocation failed. See log: $log"
  exit 1
}
