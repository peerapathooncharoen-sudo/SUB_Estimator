param(
  [string]$ProjectRoot = 'C:\Users\Admin\Desktop\SUB Estimator'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptROOT).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path
$dist = Join-Path $projectRoot 'dist'
$zip = Join-Path $dist 'SUB_Estimator_program.zip'
$meta = Join-Path $dist 'version.json'
$lib1 = Join-Path $projectRoot 'lib\html2canvas.min.js'
$lib2 = Join-Path $projectRoot 'lib\jspdf.umd.min.js'

Write-Host "Pre-run checks:"
Write-Host " - dist exists: $(Test-Path $dist)"
Write-Host " - zip present: $(Test-Path $zip) -> $zip"
Write-Host " - dist/version.json: $(Test-Path $meta)"
Write-Host " - lib html2canvas: $(Test-Path $lib1)"
Write-Host " - lib jspdf: $(Test-Path $lib2)"

if (-not (Test-Path $zip -and Test-Path $meta)) {
  Write-Warning "Essential artifacts missing (zip and/or dist/version.json). Run scripts\build-and-publish.ps1 and create_local_meta.ps1 first."
  exit 2
}
Write-Host "Basic readiness OK."

try { $out.dist_zip_sha = (Get-FileHash -Algorithm SHA256 $out.zip).Hash.ToUpper() } catch { $out.dist_zip_sha = $null }
} else { $out.dist_zip_sha = $null }

if ($out.dist_version_exists) {
  try {
    $j = Get-Content -Raw -Path $out.dist_version | ConvertFrom-Json
    $out.meta_url = $j.url
    $out.meta_version = $j.version
    $out.meta_sha = ($j.sha256).ToUpper()
    $out.meta_date = $j.date
  } catch { $out.meta_url = $null; $out.meta_version = $null; $out.meta_sha = $null; $out.meta_date = $null }
} else {
  $out.meta_url = $null; $out.meta_version = $null; $out.meta_sha = $null; $out.meta_date = $null
}

$out.sha_matches_meta = $false
if ($out.dist_zip_sha -and $out.meta_sha) { $out.sha_matches_meta = ($out.dist_zip_sha -eq $out.meta_sha) }

# important scripts
$scripts = @('scripts\build-and-publish.ps1','create_local_meta.ps1','install.ps1','install-updater-task.ps1','uninstall-updater-task.ps1','updater.ps1','run_all_commands.ps1','scripts\collect_and_package_outputs.ps1','scripts\run_full_pipeline_and_package.ps1')
$out.scripts = @{}
foreach ($s in $scripts) { $p = Join-Path $proj $s; $out.scripts[$s] = Test-Path $p }

# libs
$out.lib_html2 = Test-Path (Join-Path $proj 'lib\html2canvas.min.js')
$out.lib_jspdf = Test-Path (Join-Path $proj 'lib\jspdf.umd.min.js')

# installed (LocalAppData)
$installDir = Join-Path $env:LOCALAPPDATA 'SUB Estimator'
$out.install_dir_exists = Test-Path $installDir
$out.installed_updater = Test-Path (Join-Path $installDir 'updater.ps1')
$out.installed_version = Test-Path (Join-Path $installDir 'version.txt')

# scheduled task
$taskName = "SUB Estimator Updater"
try {
  schtasks /Query /TN "$taskName" /V /FO LIST > $null 2>&1
  $out.schtasks_exists = ($LASTEXITCODE -eq 0)
} catch { $out.schtasks_exists = $false }

# smoketest outputs
$out.smoketest_outputs = Test-Path (Join-Path $proj 'smoketest_outputs')
$out.auto_check_zips = Get-ChildItem -Path $proj -Filter 'auto_check_results_*.zip' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName

# summarize missing critical items
$out.missing = @()
if (-not $out.zip_exists) { $out.missing += 'dist zip missing' }
if (-not $out.dist_version_exists) { $out.missing += 'dist/version.json missing' }
if ($out.dist_zip_sha -and $out.meta_sha -and -not $out.sha_matches_meta) { $out.missing += 'SHA mismatch between zip and dist/version.json' }
if (-not $out.scripts['install.ps1']) { $out.missing += 'install.ps1 missing' }
if (-not $out.scripts['updater.ps1']) { $out.missing += 'updater.ps1 missing' }

# print human readable report
Write-Host "=== CHECK READY REPORT ==="
Write-Host "Project root: $proj"
Write-Host ""
Write-Host "Distribution:"
Write-Host " - dist folder: $($out.dist_exists)"
Write-Host " - zip: $($out.zip_exists) $($out.zip)"
Write-Host " - dist/version.json: $($out.dist_version_exists)"
if ($out.dist_zip_sha) { Write-Host " - zip SHA256: $($out.dist_zip_sha)" }
if ($out.meta_sha) { Write-Host " - meta.sha256: $($out.meta_sha)" }
Write-Host " - SHA matches metadata: $($out.sha_matches_meta)"
Write-Host ""
Write-Host "Scripts present (quick):"
foreach ($k in $out.scripts.Keys) { Write-Host (" - {0}: {1}" -f $k, $out.scripts[$k]) }
Write-Host ""
Write-Host "Libraries:"
Write-Host " - html2canvas: $($out.lib_html2)"
Write-Host " - jspdf: $($out.lib_jspdf)"
Write-Host ""
Write-Host "Installed on this user account:"
Write-Host " - Install dir: $($out.install_dir_exists) -> $installDir"
Write-Host " - updater.ps1 installed: $($out.installed_updater)"
Write-Host " - version.txt installed: $($out.installed_version)"
Write-Host ""
Write-Host "Scheduled task:"
Write-Host " - 'SUB Estimator Updater' exists: $($out.schtasks_exists)"
Write-Host ""
Write-Host "Smoketest / collected outputs:"
Write-Host " - smoketest_outputs folder: $($out.smoketest_outputs)"
if ($out.auto_check_zips) { Write-Host " - auto check packages found: $($out.auto_check_zips -join ', ')" }

if ($out.missing.Count -gt 0) {
  Write-Host ""
  Write-Host "Missing / warnings:"
  foreach ($m in $out.missing) { Write-Host " - $m" }
} else {
  Write-Host ""
  Write-Host "All critical files appear present. You can proceed."
}

# write JSON report for easier paste/analysis
$reportPath = Join-Path $proj 'smoketest_outputs\check_ready_report.json'
if (-not (Test-Path (Split-Path $reportPath))) { New-Item -ItemType Directory -Path (Split-Path $reportPath) | Out-Null }
$out | ConvertTo-Json -Depth 5 | Out-File -FilePath $reportPath -Encoding UTF8
Write-Host ""
Write-Host "JSON report written to: $reportPath"

Pop-Location
