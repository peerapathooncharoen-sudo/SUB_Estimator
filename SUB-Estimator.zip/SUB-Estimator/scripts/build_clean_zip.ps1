param(
    [string]$OutDir = "dist",
    [string]$ProgramZipName = 'SUB_Estimator_program.zip'
)

# Build script: create program zip and version.json inside $OutDir
# Change to repository root (assume scripts folder is inside repo root)
$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$repoRoot = Split-Path -Path $scriptDir -Parent
Set-Location -Path $repoRoot

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

$programZip = Join-Path $OutDir $ProgramZipName
if (Test-Path $programZip) { Remove-Item $programZip -Force }

# Files/folders to include in the distributable
$include = @(
    'Index.html',
    'LocalStorage.js',
    'Auth.js',
    'DatabaseCT.js',
    'DatabasePW.js',
    'login.html',
    'Register.html',
    'lib'
)

Compress-Archive -Path $include -DestinationPath $programZip -Force

$hash = (Get-FileHash -Algorithm SHA256 -Path $programZip).Hash

# determine version: prefer version.txt in repo, else fallback to '0.0.0'
$ver = '0.0.0'
if (Test-Path 'version.txt') { $ver = (Get-Content 'version.txt' -Raw).Trim() }

# version.json will point to the GitHub releases "latest" download by default
$programUrl = "https://github.com/peerapathooncharoen-sudo/SUB_Estimator/releases/latest/download/$ProgramZipName"
$meta = @{ version = $ver; url = $programUrl; sha256 = $hash } | ConvertTo-Json
$metaPath = Join-Path $OutDir 'version.json'
$meta | Out-File -FilePath $metaPath -Encoding utf8

Get-Item $programZip | Select-Object Name,Length,LastWriteTime | Format-List
Write-Output "version.json written to: $metaPath"

