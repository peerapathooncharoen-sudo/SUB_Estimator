<#
release_publish_and_sign.ps1
Automate: build zip, write metadata, optionally build installer, optionally sign, publish to GitHub release, run smoketest and collect outputs.

Usage examples:
  # local prepare + smoketest (no upload/sign)
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\release_publish_and_sign.ps1 -Version 1.2.0

  # full publish to GitHub (requires env:GITHUB_TOKEN) and tag v1.2.0
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\release_publish_and_sign.ps1 -Version 1.2.0 -Tag v1.2.0

  # build installer (ISCC required) and sign with SignTool (optional)
  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\release_publish_and_sign.ps1 -Version 1.2.0 -Tag v1.2.0 -CompileInstaller -SignCertPath 'C:\certs\mycert.pfx' -SignCertPassword 'p@ss'

Notes:
 - This script calls existing scripts in scripts\ and dev_tools\ (build-and-publish.ps1, create_local_meta.ps1, upload_github_release.ps1, smoketest_run.ps1, fetch_smoketest_outputs.ps1)
 - For signing you need Microsoft SignTool on PATH (part of Windows SDK) and a .pfx certificate file.
 - For publishing you need env:GITHUB_TOKEN set (do NOT paste token into chat).
#>

param(
  [string]$Version = '',
  [string]$Tag = '',
  [switch]$CompileInstaller,   # use Inno Setup (ISCC.exe) to compile SUB_Estimator.iss -> SUB_Estimator_Installer.exe
  [string]$ISCCPath = 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe',
  [switch]$SkipSign,
  [string]$SignCertPath = '',  # path to .pfx
  [string]$SignCertPassword = '',
  [switch]$SkipPublish,
  [switch]$SkipSmoke,
  [switch]$Force
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$scriptRoot = (Resolve-Path $PSScriptRoot).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path
$distDir = Join-Path $projectRoot 'dist'
$releaseDir = Join-Path $projectRoot 'release'
if (-not (Test-Path $releaseDir)) { New-Item -ItemType Directory -Path $releaseDir | Out-Null }

if (-not $Version) {
  $rootVer = Join-Path $projectRoot 'version.txt'
  if (Test-Path $rootVer) { $Version = (Get-Content $rootVer -Raw).Trim() }
  if (-not $Version) { throw "Version not provided and version.txt not found. Use -Version." }
}

Write-Host "Release automation - version: $Version"
$zipName = 'SUB_Estimator_program.zip'
$zipPath = Join-Path $distDir $zipName

# 1) build zip (calls build-and-publish)
Write-Host "`n[1] Build ZIP + metadata"
$buildScript = Join-Path $scriptRoot 'build-and-publish.ps1'
if (-not (Test-Path $buildScript)) { throw "Missing build script: $buildScript" }
$buildArgs = @('-Version',$Version)
if ($Force) { $buildArgs += '-Force' }
& powershell -NoProfile -ExecutionPolicy Bypass -File $buildScript @buildArgs

if (-not (Test-Path $zipPath)) { throw "ZIP not found after build: $zipPath" }

# 2) ensure metadata exists (create_local_meta)
$createMeta = Join-Path $projectRoot 'create_local_meta.ps1'
if (-not (Test-Path $createMeta)) { throw "Missing create_local_meta.ps1: $createMeta" }
& powershell -NoProfile -ExecutionPolicy Bypass -File $createMeta -ZipPath $zipPath -Version $Version

$distMeta = Join-Path $distDir 'version.json'
if (-not (Test-Path $distMeta)) { throw "dist/version.json missing after meta step." }

# compute zip sha and write .sha256 in release folder
$sha = (Get-FileHash -Algorithm SHA256 -Path $zipPath).Hash.ToUpper()
$zipReleasePath = Join-Path $releaseDir $zipName
Copy-Item -Path $zipPath -Destination $zipReleasePath -Force
$shaFile = "$zipReleasePath.sha256.txt"
$sha | Out-File -FilePath $shaFile -Encoding ASCII
Write-Host "Copied zip -> $zipReleasePath ; SHA256 -> $shaFile"

# 3) compile installer (optional)
$installerPath = Join-Path $projectRoot 'SUB_Estimator_Installer.exe'
if ($CompileInstaller) {
  Write-Host "`n[2] Compile installer using Inno Setup (ISCC)"
  if (-not (Test-Path $ISCCPath)) { throw "ISCC.exe not found at $ISCCPath. Install Inno Setup or provide correct -ISCCPath." }
  $issPath = Join-Path $projectRoot 'dev_tools\SUB_Estimator.iss'
  if (-not (Test-Path $issPath)) { throw "ISS script not found: $issPath" }
  & "$ISCCPath" "$issPath"
  if (-not (Test-Path $installerPath)) { throw "Installer exe not produced: $installerPath" }
  Copy-Item -Path $installerPath -Destination (Join-Path $releaseDir (Split-Path $installerPath -Leaf)) -Force
  Write-Host "Installer compiled and copied to release folder."
}

# 4) sign installer (optional)
if (-not $SkipSign -and $SignCertPath -and (Test-Path $SignCertPath) -and (Test-Path $installerPath)) {
  Write-Host "`n[3] Signing installer with SignTool"
  # SignTool path assumed on PATH; you can adjust to full path if needed
  $signtool = 'signtool.exe'
  $signArgs = @('sign','/f', $SignCertPath, '/p', $SignCertPassword, '/tr', 'http://timestamp.digicert.com', '/td', 'sha256', '/fd', 'sha256', $installerPath)
  $proc = Start-Process -FilePath $signtool -ArgumentList $signArgs -NoNewWindow -Wait -PassThru -ErrorAction SilentlyContinue
  if ($proc.ExitCode -ne 0) { Write-Warning "SignTool returned code $($proc.ExitCode). Installer may be unsigned." } else { Write-Host "Installer signed." }
  # copy signed installer to release folder (overwrite)
  Copy-Item -Path $installerPath -Destination (Join-Path $releaseDir (Split-Path $installerPath -Leaf)) -Force
} elseif (-not $SkipSign -and $SignCertPath -and -not (Test-Path $SignCertPath)) {
  Write-Warning "SignCertPath provided but file not found: $SignCertPath. Skipping sign."
} else {
  Write-Host "Signing skipped (SkipSign or no SignCertPath provided)."
}

# 5) publish to GitHub release (optional)
if (-not $SkipPublish) {
  if (-not $Tag) { throw "Publishing requested but -Tag not provided (e.g. v1.2.0)." }
  if (-not $env:GITHUB_TOKEN) { throw "GITHUB_TOKEN not set in environment for publish." }
  Write-Host "`n[4] Publishing to GitHub release $Tag"
  $uploader = Join-Path $projectRoot 'dev_tools\upload_github_release.ps1'
  if (-not (Test-Path $uploader)) { throw "Uploader script missing: $uploader" }
  & powershell -NoProfile -ExecutionPolicy Bypass -File $uploader -Owner 'peerapathooncharoen-sudo' -Repo 'SUB_Estimator' -Tag $Tag -ZipPath $zipReleasePath -MetaPath $distMeta
  # also attempt to upload installer and sha file via uploader if present
  $releaseInstaller = Join-Path $releaseDir (Split-Path $installerPath -Leaf)
  if (Test-Path $releaseInstaller) {
    Write-Host "Uploading installer asset..."
    & powershell -NoProfile -ExecutionPolicy Bypass -File $uploader -Owner 'peerapathooncharoen-sudo' -Repo 'SUB_Estimator' -Tag $Tag -ZipPath $releaseInstaller -MetaPath $distMeta
  }
  if (Test-Path $shaFile) {
    Write-Host "Uploading sha file..."
    & powershell -NoProfile -ExecutionPolicy Bypass -File $uploader -Owner 'peerapathooncharoen-sudo' -Repo 'SUB_Estimator' -Tag $Tag -ZipPath $shaFile -MetaPath $distMeta
  }
  Write-Host "Publish step done. Check GitHub Release page."
} else {
  Write-Host "Publish skipped (-SkipPublish specified)."
}

# 6) run smoketest (optional)
if (-not $SkipSmoke) {
  Write-Host "`n[5] Running smoketest and collecting outputs"
  $distMetaAbs = (Resolve-Path $distMeta).Path
  $fileUri = "file:///" + ($distMetaAbs -replace '\\','/')
  $smoke = Join-Path $projectRoot 'smoketest_run.ps1'
  if (Test-Path $smoke) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $smoke $fileUri
    Start-Sleep -Seconds 1
    $fetch = Join-Path $projectRoot 'fetch_smoketest_outputs.ps1'
    if (Test-Path $fetch) { & powershell -NoProfile -ExecutionPolicy Bypass -File $fetch }
    Write-Host "Smoketest invoked and outputs collected to smoketest_outputs/"
  } else {
    Write-Warning "smoketest_run.ps1 missing; skipping smoketest"
  }
} else {
  Write-Host "Smoketest skipped (-SkipSmoke specified)."
}

Write-Host "`nALL STEPS COMPLETED. Release artifacts in: $releaseDir"
Write-Host "Files of interest:"
Get-ChildItem -Path $releaseDir | Select-Object Name,Length | Format-Table -AutoSize

Param(
  [Parameter(Mandatory=$true)][string]$Tag,
  [string]$Owner = 'peerapathooncharoen-sudo',
  [string]$Repo = 'SUB_Estimator'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptROOT).Path
$build = Join-Path $scriptRoot 'build-and-publish.ps1'

if (-not (Test-Path $build)) { Write-Error "build-and-publish.ps1 missing: $build"; exit 1 }

# Build and publish
& powershell -NoProfile -ExecutionPolicy Bypass -File $build -Version (Get-Content (Join-Path $scriptRoot '..\version.txt' -ErrorAction SilentlyContinue) -ErrorAction SilentlyContinue) -Force -Publish -Tag $Tag -Owner $Owner -Repo $Repo

$releaseDir = Join-Path $scriptRoot '..\release'
if (Test-Path $releaseDir) {
  Get-ChildItem -Path $releaseDir -Filter '*.exe' -File | ForEach-Object {
    $exe = $_.FullName
    if (Get-Command 'signtool.exe' -ErrorAction SilentlyContinue) {
      Write-Host "Signing $exe via signtool.exe (best-effort)..."
      & signtool.exe sign /a /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $exe
    } else {
      Write-Host "signtool not found; skipping signing for $exe"
    }
  }
}
}
