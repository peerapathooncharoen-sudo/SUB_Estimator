param(
  [string]$InstallDir = "$env:LOCALAPPDATA\SUB Estimator",
  [string]$MetaJsonPath = "file:///C:/Users/Admin/Desktop/SUB Estimator/dist/version.json",
  [string]$TaskName = "SUB Estimator Updater"
)

# helper: locate updater.ps1 in common locations
$possible = @(
  (Join-Path $InstallDir 'updater.ps1'),
  'C:\Users\Admin\Desktop\SUB Estimator\updater.ps1',
  (Join-Path (Get-Location).Path 'updater.ps1')
)

$updater = $null
foreach ($p in $possible) { if ($p -and (Test-Path $p)) { $updater = (Resolve-Path $p).Path; break } }

if (-not $updater) {
  Write-Error "updater.ps1 not found. Ensure updater.ps1 is placed in %LocalAppData%\SUB Estimator or project root. Searched: $($possible -join '; ')"
  exit 1
}

# remove existing tasks (best-effort)
try { schtasks /Delete /TN "$TaskName" /F > $null 2>&1 } catch {}
try { schtasks /Delete /TN "$TaskName (Daily)" /F > $null 2>&1 } catch {}

# Try Register-ScheduledTask (admin path)
$created = $false
try {
  $action = New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument ("-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updater`" -MetaUrl `"$MetaJsonPath`"")
  $trLogon = New-ScheduledTaskTrigger -AtLogOn
  $trDaily = New-ScheduledTaskTrigger -Daily -At 3:00AM
  $principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trLogon,$trDaily -Principal $principal -RunLevel Highest -Force -ErrorAction Stop
  Write-Host "Registered scheduled task via Register-ScheduledTask (Admin path)."
  $created = $true
} catch {
  Write-Warning "Register-ScheduledTask failed or not running as Admin (will fallback to schtasks.exe)."
}

# Fallback: create using schtasks.exe and XML method (per-user)
if (-not $created) {
  $tr = "PowerShell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$updater`" -MetaUrl `"$MetaJsonPath`""
  $trRaw = $tr

  $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Author>$($env:USERNAME)</Author></RegistrationInfo>
  <Triggers><LogonTrigger><Enabled>true</Enabled></LogonTrigger><CalendarTrigger><StartBoundary>$((Get-Date).ToString("yyyy-MM-ddT03:00:00"))</StartBoundary><Enabled>true</Enabled><ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>$($env:USERNAME)</UserId><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings><StartWhenAvailable>true</StartWhenAvailable><Enabled>true</Enabled></Settings>
  <Actions Context="Author"><Exec><Command>PowerShell.exe</Command><Arguments><![CDATA[$trRaw]]></Arguments></Exec></Actions>
</Task>
"@

  $xmlPath = Join-Path $env:TEMP ("sub_task_{0}.xml" -f ([guid]::NewGuid().ToString("N")))
  $xml | Out-File -FilePath $xmlPath -Encoding Unicode

  try {
    $p1 = Start-Process -FilePath 'schtasks.exe' -ArgumentList "/Create","/TN",$TaskName,"/XML",$xmlPath,"/F" -NoNewWindow -Wait -PassThru -ErrorAction Stop
    if ($p1.ExitCode -eq 0) { Write-Host "Created OnLogon task via schtasks.exe (XML)." } else { Write-Warning "schtasks returned exit code $($p1.ExitCode)." }
  } catch {
    Write-Warning "schtasks (XML) onlogon failed: $($_.Exception.Message)"
  }

  try {
    $dailyName = "$TaskName (Daily)"
    $p2 = Start-Process -FilePath 'schtasks.exe' -ArgumentList "/Create","/TN",$dailyName,"/XML",$xmlPath,"/F" -NoNewWindow -Wait -PassThru -ErrorAction Stop
    if ($p2.ExitCode -eq 0) { Write-Host "Created Daily task via schtasks.exe (XML)." } else { Write-Warning "schtasks returned exit code $($p2.ExitCode)." }
  } catch {
    Write-Warning "schtasks (XML) daily failed: $($_.Exception.Message)"
  } finally {
    try { Remove-Item -Path $xmlPath -ErrorAction SilentlyContinue } catch {}
  }
}

Write-Host "`nVerify with:"
Write-Host "  schtasks /Query /TN `"$TaskName`" /V /FO LIST"
Write-Host "  schtasks /Query /TN `"$TaskName (Daily)`" /V /FO LIST"
      <Command>PowerShell.exe</Command>
      <Arguments><![CDATA[$tr]]></Arguments>
    </Exec>
  </Actions>
</Task>
"@

  $xmlPath = Join-Path $env:TEMP ("sub_task_{0}.xml" -f ([guid]::NewGuid().ToString("N")))
  $xml | Out-File -FilePath $xmlPath -Encoding Unicode

  try {
    # create task from XML (per-user)
    $proc = Start-Process -FilePath 'schtasks.exe' -ArgumentList "/Create","/TN",$TaskName,"/XML",$xmlPath,"/F" -NoNewWindow -Wait -PassThru -ErrorAction Stop
    if ($proc.ExitCode -eq 0) { Write-Host "Created scheduled task via schtasks.exe (XML)." } else { Write-Warning "schtasks returned exit code $($proc.ExitCode)." }
  } catch {
    Write-Warning "schtasks (XML) failed: $($_.Exception.Message)"
  } finally {
    try { Remove-Item -Path $xmlPath -ErrorAction SilentlyContinue } catch {}
  }
}

Write-Host ""
Write-Host "Verify with:"
Write-Host "  schtasks /Query /TN `"$TaskName`" /V /FO LIST"
Write-Host "  schtasks /Query /TN `"$TaskName (Daily)`" /V /FO LIST"
Write-Host "`nOnLogon task:"
schtasks /Query /TN "$TaskName" /V /FO LIST 2>&1 | Write-Host
Write-Host "`nDaily task:"
schtasks /Query /TN "$TaskName (Daily)" /V /FO LIST 2>&1 | Write-Host

Write-Host "`nDone. If creation failed due to permissions, re-run this script in an elevated PowerShell (Run as Administrator) to allow Register-ScheduledTask to run."
