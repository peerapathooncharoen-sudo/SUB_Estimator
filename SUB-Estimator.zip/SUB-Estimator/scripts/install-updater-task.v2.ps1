﻿param(
  [Parameter(Mandatory=$true)][string]$Source,
  [string]$TaskName = "SUB Estimator Updater (v2)"
)
$ErrorActionPreference = "Stop"
$configPath = Join-Path $PSScriptRoot "update.config.json"
@{ Source = $Source } | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8

try { schtasks /Query /TN "$TaskName" >$null 2>&1; if ($LASTEXITCODE -eq 0) { schtasks /Delete /TN "$TaskName" /F | Out-Null } } catch {}

$updater = Join-Path $PSScriptRoot "updater.v2.ps1"
$arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updater`""
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
$triggers = @(
  New-ScheduledTaskTrigger -AtLogOn
  New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepetitionDuration ([TimeSpan]::MaxValue)
)
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -RunLevel Highest -Force | Out-Null
Write-Host "Installed task ''$TaskName''."
