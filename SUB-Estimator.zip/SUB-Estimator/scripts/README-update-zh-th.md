คำตอบสั้นๆ — ไม่ต้องอัพเดตด้วยมือทุกครั้ง

1) ทางเลือกที่ผมเพิ่มให้แล้ว
- GitHub Actions (CI): ถ้าคุณ push ไปที่สาขา `main` หรือสั่ง workflow ด้วยมือ ระบบจะรันสคริปต์สร้าง `dist/SUB_Estimator_CleanRelease.zip` ให้โดยอัตโนมัติ แล้ว commit กลับ (รวม [skip ci]) และอัปโหลดเป็น artifact — คุณไม่ต้องทำเองบนเครื่อง
- Local watcher (PowerShell): ถ้าคุณอยากให้เครื่องพัฒนา rebuild อัตโนมัติ ให้รัน `scripts\watch-and-build.ps1` ใน PowerShell แล้วมันจะเรียก `scripts\build_clean_zip.ps1` ทุกครั้งที่ไฟล์เปลี่ยน (debounce 800ms)

2) วิธีทดสอบ (สั้น ๆ)
- Local: เปิด PowerShell ในโฟลเดอร์โปรเจค แล้วรัน:
  powershell -ExecutionPolicy Bypass -File .\scripts\watch-and-build.ps1
  แก้ `Index.html` แล้วบันทึก แล้วดู `dist\SUB_Estimator_CleanRelease.zip` ถูกอัพเดตหรือไม่

- CI: Push commit ขึ้น `main` (หรือใช้ Actions -> Run workflow) แล้วดู Action logs ว่า `dist/SUB_Estimator_CleanRelease.zip` ถูกสร้างและถูก commit กลับหรือ upload artifact

3) ถ้าต้องบังคับให้อัพเดตผู้ใช้ปลายทาง (เครื่องที่ใช้ updater)
- เพิ่มเวอร์ชันใหม่ใน `version.txt`/`version.json` ที่ updater อ่าน และอัปโหลด ZIP ใหม่ไปไว้ที่ Release หรือที่ URL ที่ updater ตรวจสอบ
- ถัดไป updater จะดาวน์โหลด ZIP เวอร์ชันใหม่โดยอัตโนมัติ

4) หมายเหตุการตั้งค่า
- ถ้าใช้ GitHub Actions ให้แน่ใจว่า branch ปลายทางคือ `main` หรือแก้ workflow ให้ชี้สาขาที่คุณใช้
- workflow ถูกตั้งให้รันบน `windows-latest` และใช้ PowerShell Core (pwsh) เพื่อเรียกสคริปต์ที่มีอยู่
- commit กลับจะใส่ข้อความ "ci: update distributable ZIP [skip ci]" เพื่อหลีกเลี่ยง loop

ถ้าต้องการ ผมจะ:
- (A) แก้ `scripts\build_clean_zip.ps1` ให้แน่ใจว่ามันเลือกเฉพาะไฟล์ที่ต้องการ
- (B) เพิ่มตัวเลือกให้ workflow สร้าง Release หรืออัปโหลดไปยัง GitHub Release โดยตรง
- (C) ช่วยตั้งค่า token/secret ถ้าจะ push กลับไปยัง branch protected

บอกผมว่าต้องการตัวเลือก A/B/C อันไหนต่อครับ