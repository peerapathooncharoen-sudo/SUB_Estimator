param(
  [string]$ProjectRoot = 'C:\Users\Admin\Desktop\SUB Estimator',
  [string]$Version = '1.2.0',
  [switch]$ElevateInstall   # ถ้าระบุ จะเรียก install.ps1 ด้วยการยกระดับ (RunAs) เพื่อให้ Register-ScheduledTask สำเร็จเต็มรูปแบบ
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptRoot).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path

Write-Host "ProjectRoot: $ProjectRoot"
Push-Location $ProjectRoot

try {
  Write-Host "1) Download libs (if missing)"
  if (Test-Path '.\scripts\download-libs.ps1') {
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\download-libs.ps1
  }

  Write-Host "2) Build ZIP and write metadata"
  if (-not (Test-Path ".\scripts\build-and-publish.ps1")) { throw "Missing build-and-publish.ps1" }
  & powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\build-and-publish.ps1 -Version $Version -Force

  Write-Host "3) Ensure metadata exists (create_local_meta.ps1)"
  if (Test-Path '.\create_local_meta.ps1') {
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\create_local_meta.ps1 -ZipPath ".\dist\SUB_Estimator_program.zip" -Version $Version
  }

  Write-Host "4) Install package and register updater (per-user)"
  $installCmd = "-NoProfile -ExecutionPolicy Bypass -File `"$PWD\install.ps1`" -SourceZip `"$PWD\dist\SUB_Estimator_program.zip`" -RegisterUpdater"
  if ($ElevateInstall) {
    Write-Host " - Elevating install step (RunAs)... (you will see UAC prompt)"
    Start-Process -FilePath "powershell.exe" -ArgumentList $installCmd -Verb RunAs -Wait
  } else {
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -SourceZip .\dist\SUB_Estimator_program.zip -RegisterUpdater
  }

  Write-Host "5) Run full pipeline and collect outputs (run_all_commands)"
  if (Test-Path '.\run_all_commands.ps1') {
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\run_all_commands.ps1 -Version $Version
  } else {
    Write-Host " - run_all_commands.ps1 not found; will attempt to run smoke/collect steps individually"
    if (Test-Path '.\scripts\do_everything_local.ps1') {
      & powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\do_everything_local.ps1 -Version $Version
    }
  }

  Write-Host "6) Create packaged results (collect_and_package_outputs.ps1)"
  if (Test-Path '.\scripts\collect_and_package_outputs.ps1') {
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\collect_and_package_outputs.ps1 -ProjectRoot $ProjectRoot
    # the collect script prints the zip path and SHA
  } else {
    Write-Host " - collect_and_package_outputs.ps1 not found. Please run scripts\\collect_and_package_outputs.ps1 manually to collect results."
  }

  Write-Host "DONE. หากสร้าง ZIP แล้ว ให้ส่งไฟล์ ZIP หรือผลลัพธ์ (stdout) กลับมาผมจะวิเคราะห์ต่อ"
} catch {
  Write-Error "Pipeline failed: $_"
  exit 1
} finally {
  Pop-Location
}

# invoke smoketest + outputs + create single-file bundle
$doAll = Join-Path $projectRoot 'scripts\do_everything_local.ps1'
$bundle = Join-Path $projectRoot 'scripts\create_bundle_zip.ps1'

if (Test-Path $doAll) {
  Write-Host "Running local pipeline..."
  & powershell -NoProfile -ExecutionPolicy Bypass -File $doAll
} else { Write-Warning "do_everything_local.ps1 missing; skipping pipeline step." }

if (Test-Path $bundle) {
  Write-Host "Creating distributable bundle..."
  & powershell -NoProfile -ExecutionPolicy Bypass -File $bundle
} else { Write-Warning "create_bundle_zip.ps1 missing; skipping bundle step." }

Write-Host "run_full_pipeline_and_package completed."
