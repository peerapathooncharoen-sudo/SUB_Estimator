$repo='C:\Users\Admin\Desktop\SUB Estimator'
$zip=Join-Path $repo 'dist\SUB_Estimator_program.zip'
if (-not (Test-Path $zip)) { Write-Error 'Program zip not found'; exit 2 }
$sha=(Get-FileHash -Algorithm SHA256 $zip).Hash
$metaPath=Join-Path $env:TEMP 'sub_meta_local.json'
$uri='file:///' + ($zip -replace '\\','/')
@{url=$uri; version='9.9.9'; sha256=$sha} | ConvertTo-Json | Out-File -FilePath $metaPath -Encoding utf8
Write-Host "Wrote meta: $metaPath"
$installDir=Join-Path $env:TEMP 'sub_test_install'
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $installDir | Out-Null
'1.0.0' | Out-File -FilePath (Join-Path $installDir 'version.txt') -Encoding utf8
'original' | Out-File -FilePath (Join-Path $installDir 'old.txt') -Encoding utf8
Write-Host "InstallDir prepared: $installDir"
Write-Host 'Running updater (local test)...'
& "$repo\updater.ps1" -MetaUrl $metaPath -InstallDir $installDir
Write-Host 'Updater exit. InstallDir listing:'
Get-ChildItem -Path $installDir -Recurse | Select-Object FullName,Length | Format-Table -AutoSize
