param(
  [string]$ProjectRoot = 'C:\Users\Admin\Desktop\SUB Estimator'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptRoot = (Resolve-Path $PSScriptROOT).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path
$src = Join-Path $env:TEMP 'sub_estimator_smoketest'
$dst = Join-Path $projectRoot 'smoketest_outputs'
$zip = Join-Path $projectRoot 'dist\smoketest_outputs.zip'

if (Test-Path $dst) { Remove-Item -Recurse -Force $dst -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $dst | Out-Null

if (Test-Path $src) {
  Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Copied smoketest outputs to: $dst"
} else {
  Write-Warning "Smoketest outputs source not found: $src"
}

if (Test-Path $zip) { Remove-Item $zip -Force -ErrorAction SilentlyContinue }
if ((Get-ChildItem -Path $dst -Recurse -File -ErrorAction SilentlyContinue).Count -gt 0) {
  Compress-Archive -Path (Join-Path $dst '*') -DestinationPath $zip -Force
  Write-Host "Created smoketest archive: $zip"
} else {
  Write-Warning "No smoketest outputs to archive."
}

# resolve paths
$projectRoot = (Resolve-Path $ProjectRoot).Path
Set-Location $projectRoot
$time = (Get-Date).ToString('yyyyMMdd_HHmmss')
$outBase = Join-Path $projectRoot "auto_check_results_$time"
$outDir = $outBase
if (Test-Path $outDir) { Remove-Item -Recurse -Force $outDir -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $outDir | Out-Null

Info "ProjectRoot: $projectRoot"
Info "Output folder: $outDir"

# 1) Try run run_all_commands.ps1 (if present) to collect smoketest_outputs automatically
$runner = Join-Path $projectRoot 'run_all_commands.ps1'
if (Test-Path $runner) {
  Info "Running run_all_commands.ps1 ..."
  try {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $runner 2>&1 | Tee-Object -FilePath (Join-Path $outDir 'run_all_commands_stdout.txt')
    Info "run_all_commands finished (stdout saved)."
  } catch {
    Write-Warning "run_all_commands failed: $_"
  }
} else {
  Info "run_all_commands.ps1 not found — skipping automated pipeline run."
}

# 2) Collect smoketest_outputs (if created)
$smokeSrc = Join-Path $projectRoot 'smoketest_outputs'
if (Test-Path $smokeSrc) {
  Info "Copying smoketest_outputs ..."
  Copy-Item -Path (Join-Path $smokeSrc '*') -Destination (Join-Path $outDir 'smoketest_outputs') -Recurse -Force -ErrorAction SilentlyContinue
} else {
  Info "No smoketest_outputs folder found."
}

# 3) Collect dist metadata and zip + compute SHA
$dist = Join-Path $projectRoot 'dist'
if (Test-Path $dist) {
  if (Test-Path (Join-Path $dist 'version.json')) {
    Copy-Item -Path (Join-Path $dist 'version.json') -Destination (Join-Path $outDir 'dist_version.json') -Force
  }
  $zipPath = Join-Path $dist 'SUB_Estimator_program.zip'
  if (Test-Path $zipPath) {
    Copy-Item -Path $zipPath -Destination (Join-Path $outDir 'SUB_Estimator_program.zip') -Force
    $hash = (Get-FileHash -Algorithm SHA256 -Path $zipPath).Hash.ToUpper()
    $hash | Out-File -FilePath (Join-Path $outDir 'SUB_Estimator_program.zip.sha256.txt') -Encoding ASCII
    Info "Collected dist ZIP and SHA256."
  } else {
    Info "dist ZIP not found."
  }
} else {
  Info "dist folder not found."
}

# 4) Collect installed updater files (LocalAppData)
$installDir = Join-Path $env:LOCALAPPDATA 'SUB Estimator'
if (Test-Path $installDir) {
  Info "Collecting installed files from $installDir ..."
  Copy-Item -Path (Join-Path $installDir '*') -Destination (Join-Path $outDir 'installed_copy') -Recurse -Force -ErrorAction SilentlyContinue
} else {
  Info "No installed folder at $installDir"
}

# 5) Query scheduled task info
$taskName = "SUB Estimator Updater"
$schtOut = Join-Path $outDir 'schtasks_query.txt'
try {
  schtasks /Query /TN "$taskName" /V /FO LIST 2>&1 | Out-File -FilePath $schtOut -Encoding UTF8
  Info "Scheduled task query saved to: $schtOut"
} catch {
  "schtasks query failed: $_" | Out-File -FilePath $schtOut -Encoding UTF8
  Info "schtasks query failed (see file)."
}

# 6) Capture updater manual run summary (if updater exists)
$updaterInstalled = Join-Path $installDir 'updater.ps1'
$metaFile = Join-Path $projectRoot 'dist\version.json'
$manualOut = Join-Path $outDir 'manual_updater_run.txt'
if (Test-Path $updaterInstalled -and Test-Path $metaFile) {
  $metaAbs = (Resolve-Path $metaFile).Path
  $uri = "file:///" + ($metaAbs -replace '\\','/')
  Info "Running updater manually (will save stdout to $manualOut) ..."
  try {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $updaterInstalled -MetaUrl $uri 2>&1 | Tee-Object -FilePath $manualOut
  } catch {
    "Manual updater run failed: $_" | Out-File -FilePath $manualOut -Encoding UTF8
  }
} else {
  Info "Cannot run updater manually (missing updater or metadata)."
}

# 7) Basic environment info
$envOut = Join-Path $outDir 'env_info.txt'
@(
  "User: $(whoami 2>$null)",
  "Date: $(Get-Date -Format s)",
  "PSVersion: $($PSVersionTable.PSVersion)",
  "LocalAppData: $env:LOCALAPPDATA",
  "ProjectRoot: $projectRoot"
) | Out-File -FilePath $envOut -Encoding UTF8

# 8) Create zip package of collected outputs
$zipDest = "$outBase.zip"
if (Test-Path $zipDest) { Remove-Item $zipDest -Force -ErrorAction SilentlyContinue }
try {
  Compress-Archive -Path (Join-Path $outDir '*') -DestinationPath $zipDest -Force
  Info "Created package: $zipDest"
  $finalHash = (Get-FileHash -Algorithm SHA256 -Path $zipDest).Hash.ToUpper()
  $finalHash | Out-File -FilePath ("$zipDest.sha256.txt") -Encoding ASCII
  Info "SHA256($zipDest) = $finalHash"
} catch {
  Write-Warning "Failed to create package: $_"
}

# 9) Open explorer on folder for convenience
try { Start-Process -FilePath (Split-Path $zipDest) } catch {}

Write-Host ""
Write-Host "สรุป: ผลลัพธ์ถูกเก็บที่: $zipDest"
Write-Host "SHA256: $finalHash"
Write-Host "โปรดส่งไฟล์ ZIP นี้มาให้ผม (หรืออัปโหลดไปที่คลาวด์แล้วให้ลิงก์) เพื่อให้ผมวิเคราะห์ต่อ"
