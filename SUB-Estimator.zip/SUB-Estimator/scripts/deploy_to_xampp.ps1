Param(
  [string]$ProjectRoot = "C:\Users\Admin\Desktop\SUB Estimator",
  [string]$XamppTarget = "C:\xampp\htdocs\SUB-Estimator",
  [switch]$CreateBackup,   # create backup zip of target before overwrite
  [switch]$Force           # skip confirmations
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not (Test-Path $ProjectRoot)) { Write-Error "Project root not found: $ProjectRoot"; exit 1 }

# ensure target exists (create if missing)
if (-not (Test-Path $XamppTarget)) {
  Write-Host "Target $XamppTarget does not exist. Creating..."
  try { New-Item -ItemType Directory -Path $XamppTarget -Force | Out-Null } catch { Write-Error "Failed to create target: $_"; exit 1 }
}

$confirm = $Force -or (Read-Host "Deploy from `"$ProjectRoot`" -> `"$XamppTarget`". Proceed? (y/N)" ) -match '^[yY]'

if (-not $confirm) { Write-Host "Aborted by user."; exit 0 }

# optional backup
if ($CreateBackup) {
  $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
  $bk = Join-Path $env:TEMP ("SUB-Estimator-xampp-backup_$ts.zip")
  Write-Host "Creating backup of target -> $bk"
  try {
    Compress-Archive -Path (Join-Path $XamppTarget '*') -DestinationPath $bk -Force
    Write-Host "Backup completed: $bk"
  } catch { Write-Warning "Backup failed: $_" }
}

# Use robocopy if available for faster sync, otherwise fallback to Copy-Item
$robocopy = (Get-Command robocopy.exe -ErrorAction SilentlyContinue).Path
if ($robocopy) {
  Write-Host "Syncing with robocopy (preserve timestamps/perf)..."
  # exclude some heavy dev folders by default
  $exclude = @("dev_tools",".git",".github","node_modules")
  $excludeArgs = $exclude | ForEach-Object { "/XD `"$ProjectRoot\$_`"" }
  $rcArgs = @($ProjectRoot, $XamppTarget, "/MIR", "/FFT", "/XO", "/R:2", "/W:2") + $excludeArgs
  & robocopy @rcArgs | Write-Host
  $rcExit = $LASTEXITCODE
  if ($rcExit -gt 8) { Write-Warning "Robocopy reported exit code $rcExit (possible failures)." }
} else {
  Write-Host "Robocopy not found - using Copy-Item (slower)."
  # copy files and folders (overwrite)
  try {
    Get-ChildItem -Path $ProjectRoot -Force | Where-Object { $_.Name -notin @('dev_tools','.git','.github','node_modules') } | ForEach-Object {
      $src = $_.FullName
      $dest = Join-Path $XamppTarget $_.Name
      if (Test-Path $dest) { Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue }
      Copy-Item -Path $src -Destination $dest -Recurse -Force
    }
  } catch { Write-Warning "Copy-Item failed: $_" }
}

# Touch HTML/JS/CSS files in target to update LastWriteTime (cache-buster)
$touchPatterns = @('*.html','*.js','*.css')
foreach ($pat in $touchPatterns) {
  Get-ChildItem -Path $XamppTarget -Filter $pat -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
    try { $_.LastWriteTime = Get-Date } catch {}
  }
}

# ensure dist/.htaccess exists to allow CORS (best-effort)
$distHt = Join-Path $XamppTarget 'dist\.htaccess'
if (-not (Test-Path $distHt)) {
  $ht = @"
<IfModule mod_headers.c>
  Header set Cache-Control "no-cache, no-store, must-revalidate"
  Header set Pragma "no-cache"
  Header set Expires "0"
  Header set Access-Control-Allow-Origin "*"
  Header set Access-Control-Allow-Methods "GET,OPTIONS"
  Header set Access-Control-Allow-Headers "Content-Type"
</IfModule>
Options -Indexes
"@
  try { $ht | Out-File -FilePath $distHt -Encoding UTF8 -Force; Write-Host "Wrote dist/.htaccess to target (CORS + no-cache)" } catch { Write-Warning "Failed to write .htaccess: $_" }
}

Write-Host "`nDeployment complete. Verify in browser: http://localhost/$(Split-Path -Leaf $XamppTarget)/Index.html"
Write-Host "If page still shows old content, open DevTools -> Network -> Disable cache -> Reload, or clear browser cache."
