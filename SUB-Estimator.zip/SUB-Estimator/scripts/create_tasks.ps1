param(
  [string]$InstallDir = "$env:LOCALAPPDATA\SUB Estimator",
  [string]$MetaJson = "file:///C:/Users/Admin/Desktop/SUB Estimator/dist/version.json",
  [string]$TaskName = "SUB Estimator Updater"
)

$updater = Join-Path $InstallDir 'updater.ps1'
if (-not (Test-Path $updater)) {
  Write-Error "updater.ps1 not found at $updater. Place updater.ps1 in $InstallDir first."
  exit 1
}

# Build TR (task run) string
$tr = "PowerShell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$updater`" -MetaUrl `"$MetaJson`""

Write-Host "Creating scheduled task: $TaskName (OnLogon) -> $tr"

# Prepare argument arrays for schtasks.exe (each element is a separate argument)
$createArgs1 = @(
  '/Create',
  '/TN', $TaskName,
  '/TR', $tr,
  '/SC', 'ONLOGON',
  '/RL', 'LIMITED',
  '/F',
  '/RU', $env:USERNAME
)

# Run schtasks with argument array
try {
  $procOut = & schtasks.exe @createArgs1 2>&1
  if ($LASTEXITCODE -ne 0) {
    Write-Warning ("Failed to create {0}: {1}" -f $TaskName, ($procOut -join "`n"))
  } else {
    Write-Host "Created: $TaskName"
  }
} catch {
  Write-Warning ("Failed to create {0}: {1}" -f $TaskName, $_)
}

# Daily task
$dailyName = "$TaskName (Daily)"
Write-Host "Creating scheduled task: $dailyName (Daily 03:00) -> $tr"

$createArgs2 = @(
  '/Create',
  '/TN', $dailyName,
  '/TR', $tr,
  '/SC', 'DAILY',
  '/ST', '03:00',
  '/RL', 'LIMITED',
  '/F',
  '/RU', $env:USERNAME
)

try {
  $procOut2 = & schtasks.exe @createArgs2 2>&1
  if ($LASTEXITCODE -ne 0) {
    Write-Warning ("Failed to create {0}: {1}" -f $dailyName, ($procOut2 -join "`n"))
  } else {
    Write-Host "Created: $dailyName"
  }
} catch {
  Write-Warning ("Failed to create {0}: {1}" -f $dailyName, $_)
}

Write-Host ""
Write-Host "Verify with:"
Write-Host "  schtasks /Query /TN `"$TaskName`" /V /FO LIST"
Write-Host "  schtasks /Query /TN `"$dailyName`" /V /FO LIST"