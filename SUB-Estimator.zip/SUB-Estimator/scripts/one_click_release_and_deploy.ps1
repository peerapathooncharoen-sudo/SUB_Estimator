Param(
  [string]$Version = '',                 # e.g. "1.2.1"
  [string]$Tag = '',                     # e.g. "v1.2.1" (required for GitHub publish)
  [switch]$CompileInstaller,             # compile Inno Setup .iss if available
  [string]$ISCCPath = 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe',
  [switch]$PublishToGitHub,              # requires env:GITHUB_TOKEN and Tag
  [switch]$CreateBundle,                 # run create_bundle_zip.ps1 to create full bundle
  [switch]$CopyToXAMPP,                  # copy dist ZIP + version.json to XAMPP htdocs
  [string]$XAMPPPath = 'C:\xampp\htdocs\SUB-Estimator', # destination root (htdocs subfolder)
  [switch]$RegisterClientCommands,       # emit client commands file for admins to run on clients
  [switch]$Force
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$scriptRoot = (Resolve-Path $PSScriptRoot).Path
$projectRoot = (Resolve-Path (Join-Path $scriptRoot '..')).Path
$distDir = Join-Path $projectRoot 'dist'
$releaseDir = Join-Path $projectRoot 'release'
if (-not (Test-Path $distDir)) { New-Item -ItemType Directory -Path $distDir | Out-Null }
if (-not (Test-Path $releaseDir)) { New-Item -ItemType Directory -Path $releaseDir | Out-Null }

Write-Host "ONE-CLICK: Release & Deploy"
Write-Host "ProjectRoot: $projectRoot"
Write-Host "Dist: $distDir"
if ($Version) { Write-Host "Requested Version: $Version" }
if ($Tag) { Write-Host "Requested Tag: $Tag" }

function RunScriptIfExists($path, [string[]]$args = @()) {
  if (Test-Path $path) {
    Write-Host "Invoking: $path $($args -join ' ')"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $path @args
    return $true
  } else {
    Write-Warning "Script not found: $path"
    return $false
  }
}

# 1) Build ZIP: prefer scripts\build-and-publish.ps1, fallback to scripts\build-and-publish.ps1 in project
$buildScript = Join-Path $scriptRoot 'build-and-publish.ps1'
$altBuild = Join-Path $projectRoot 'scripts\build-and-publish.ps1'
if (-not $Version) {
  $vfile = Join-Path $projectRoot 'version.txt'
  if (Test-Path $vfile) { $Version = (Get-Content $vfile -Raw).Trim() }
}
if (-not $Version) { $Version = '0.0.0' }

$built = $false
if (Test-Path $buildScript) {
  $buildArgs = @('-Version', $Version)
  if ($Force) { $buildArgs += '-Force' }
  $built = RunScriptIfExists $buildScript $buildArgs
} elseif (Test-Path $altBuild) {
  $buildArgs = @('-Version', $Version)
  if ($Force) { $buildArgs += '-Force' }
  $built = RunScriptIfExists $altBuild $buildArgs
} else {
  Write-Warning "No build script found (build-and-publish.ps1). Attempting to build using create_bundle_zip if present."
}

# 2) Create metadata (create_local_meta) — if copying to XAMPP, generate HostUrl for HTTP access
$createMeta = Join-Path $projectRoot 'create_local_meta.ps1'
$zipPath = Join-Path $distDir 'SUB_Estimator_program.zip'
if (-not (Test-Path $zipPath)) {
  Write-Warning "ZIP not found at $zipPath (build may have failed). Attempting to continue if you intend to use existing zip."
}
$hostUrl = ''
if ($CopyToXAMPP) {
  # ensure XAMPP path exists, create subfolders
  if (-not (Test-Path $XAMPPPath)) {
    try { New-Item -ItemType Directory -Path $XAMPPPath -Force | Out-Null; Write-Host "Created XAMPP path: $XAMPPPath" } catch { Write-Warning "Cannot create XAMPP path: $_"; $CopyToXAMPP = $false }
  }
  if ($CopyToXAMPP) {
    $hostUrl = "http://localhost/" + (Split-Path -Leaf $XAMPPPath) + "/dist"
  }
}

if (Test-Path $createMeta) {
  $metaArgs = @('-ZipPath', $zipPath, '-Version', $Version)
  if ($hostUrl) { $metaArgs += '-HostUrl'; $metaArgs += $hostUrl }
  RunScriptIfExists $createMeta $metaArgs
} else {
  Write-Warning "create_local_meta.ps1 not found; skipping metadata creation."
}

# 3) Compile installer (optional)
$installerPath = Join-Path $projectRoot 'SUB_Estimator_Installer.exe'
if ($CompileInstaller) {
  $issCandidates = @((Join-Path $projectRoot 'SUB_Estimator.iss'), (Join-Path $projectRoot 'dev_tools\SUB_Estimator.iss'))
  $iss = $issCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $iss) { Write-Warning "No .iss found; cannot compile installer." } else {
    if (-not (Test-Path $ISCCPath)) { Write-Warning "ISCC not found at $ISCCPath; attempting to find on PATH"; $ISCCPath = (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Path }
    if (-not (Test-Path $ISCCPath)) { Write-Warning "ISCC not found; skipping compile." } else {
      Write-Host "Compiling installer with ISCC: $ISCCPath $iss"
      & "$ISCCPath" "`"$iss`""
      if (Test-Path $installerPath) {
        Write-Host "Installer compiled: $installerPath"
        Copy-Item -Path $installerPath -Destination (Join-Path $releaseDir (Split-Path $installerPath -Leaf)) -Force
      } else {
        Write-Warning "Installer not produced at expected path: $installerPath"
      }
    }
  }
}

# 4) Publish to GitHub (optional)
if ($PublishToGitHub) {
  if (-not $Tag) { throw "Publishing requested but -Tag not provided." }
  if (-not $env:GITHUB_TOKEN) { throw "GITHUB_TOKEN not set in environment for publish." }
  $pubScript = Join-Path $projectRoot 'scripts\release_publish_and_sign.ps1'
  if (Test-Path $pubScript) {
    # call publish script with tag/version
    & powershell -NoProfile -ExecutionPolicy Bypass -File $pubScript -Version $Version -Tag $Tag -Force
  } else {
    Write-Warning "publish script not found: $pubScript"
  }
}

# 5) Create full bundle (optional)
if ($CreateBundle) {
  $bundleScript = Join-Path $projectRoot 'scripts\create_bundle_zip.ps1'
  if (Test-Path $bundleScript) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $bundleScript
  } else {
    Write-Warning "create_bundle_zip.ps1 not found; skipping bundle creation."
  }
}

# 6) Copy to XAMPP (optional)
if ($CopyToXAMPP) {
  $distTarget = Join-Path $XAMPPPath 'dist'
  if (-not (Test-Path $distTarget)) { New-Item -ItemType Directory -Path $distTarget -Force | Out-Null }
  # copy zip and version.json
  $srcZip = $zipPath
  $srcMeta = Join-Path $distDir 'version.json'
  if (Test-Path $srcZip) { Copy-Item -Path $srcZip -Destination (Join-Path $distTarget (Split-Path $srcZip -Leaf)) -Force; Write-Host "Copied ZIP -> $distTarget" } else { Write-Warning "ZIP missing; not copied." }
  if (Test-Path $srcMeta) { Copy-Item -Path $srcMeta -Destination (Join-Path $distTarget 'version.json') -Force; Write-Host "Copied version.json -> $distTarget" } else { Write-Warning "dist/version.json missing; not copied." }

  # create .htaccess to allow CORS (best-effort)
  $htaccess = Join-Path $distTarget '.htaccess'
  $httext = @"
<IfModule mod_headers.c>
  Header set Access-Control-Allow-Origin "*"
  Header set Access-Control-Allow-Methods "GET,OPTIONS"
  Header set Access-Control-Allow-Headers "Content-Type"
  Header set Access-Control-Max-Age "3600"
</IfModule>
Options -Indexes
"@
  try { $httext | Out-File -FilePath $htaccess -Encoding UTF8 -Force; Write-Host "Wrote .htaccess to $distTarget" } catch { Write-Warning "Failed to write .htaccess: $_" }
  Write-Host "XAMPP deploy complete. Verify via: http://localhost/$(Split-Path -Leaf $XAMPPPath)/dist/version.json"
}

# 7) Emit client install commands (file) for admins to run on client machines
$clientCmdFile = Join-Path $projectRoot 'release\client_install_commands.txt'
$metaUrlForClients = ''
if (Test-Path (Join-Path $distDir 'version.json')) {
  $meta = Get-Content -Raw -Path (Join-Path $distDir 'version.json') | ConvertFrom-Json
  $metaUrlForClients = $meta.url
}
if ($CopyToXAMPP -and $hostUrl) { $metaUrlForClients = "$hostUrl/version.json" }

$lines = @()
$lines += "# Client install commands (run on client machine as user)"
$lines += "# 1) Install program (from local file or network share)"
$lines += "powershell -NoProfile -ExecutionPolicy Bypass -File `"$projectRoot\install.ps1`" -SourceZip `"$zipPath`" -RegisterUpdater"
$lines += ""
if ($metaUrlForClients) {
  $lines += "# 2) To test updater immediately (manual):"
  $lines += "powershell -NoProfile -ExecutionPolicy Bypass -File `"$env:LOCALAPPDATA\SUB Estimator\updater.ps1`" -MetaUrl `"$metaUrlForClients`""
  $lines += ""
  $lines += "# 3) To register scheduled task manually (if installer couldn't):"
  $lines += "powershell -NoProfile -ExecutionPolicy Bypass -File `"$projectRoot\install-updater-task.ps1`" -MetaUrl `"$metaUrlForClients`""
} else {
  $lines += "# NOTE: No metadata URL available; update/create dist/version.json first."
}
$lines | Out-File -FilePath $clientCmdFile -Encoding UTF8 -Force
Write-Host "Wrote client commands: $clientCmdFile"

# 8) Summary and next steps
Write-Host "`n=== ONE-CLICK SUMMARY ==="
if (Test-Path $zipPath) { Write-Host " - ZIP: $zipPath" }
if (Test-Path (Join-Path $distDir 'version.json')) { Write-Host " - dist/version.json: $(Join-Path $distDir 'version.json')" }
if ($CopyToXAMPP) { Write-Host " - Copied to XAMPP: $XAMPPPath/dist" }
if ($CreateBundle) { Write-Host " - Bundle created in dist (check dist folder)" }
if ($PublishToGitHub) { Write-Host " - Publish requested (check GitHub releases for tag $Tag)" }
Write-Host " - Client install commands: $clientCmdFile"
Write-Host "`nRun the generated client commands on each client machine (or distribute $clientCmdFile to admins)."
Write-Host "Done."
