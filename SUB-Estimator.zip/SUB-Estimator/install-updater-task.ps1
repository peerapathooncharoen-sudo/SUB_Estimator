<#
install-updater-task.ps1
Installs a per-user scheduled task to run updater.ps1 at user logon.

Usage:
  powershell -ExecutionPolicy Bypass -File .\install-updater-task.ps1 [-MetaUrl 'file:///C:/.../version.json']
#>
Param(
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$TaskName = 'SUB Estimator Updater',
  [string]$MetaUrl = ''
)

$updaterPath = Join-Path $InstallDir 'updater.ps1'
if (-not (Test-Path $updaterPath)) { Write-Error "updater.ps1 not found at $updaterPath" ; exit 1 }

$arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updaterPath`""
if (-not [string]::IsNullOrWhiteSpace($MetaUrl)) { $arg += " -MetaUrl `"$MetaUrl`"" }

$action = New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument $arg
$triggerLogon = New-ScheduledTaskTrigger -AtLogOn
$triggerDaily = New-ScheduledTaskTrigger -Daily -At 3:00AM
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive

try {
  Register-ScheduledTask -Action $action -Trigger $triggerLogon,$triggerDaily -TaskName $TaskName -Principal $principal -Force | Out-Null
  if ($MetaUrl) { Write-Host "Scheduled task '$TaskName' installed for user $env:USERNAME (AtLogOn + Daily) with MetaUrl: $MetaUrl" } else { Write-Host "Scheduled task '$TaskName' installed for user $env:USERNAME (AtLogOn + Daily)" }
} catch {
  Write-Warning "Register-ScheduledTask failed: $($_.Exception.Message). Falling back to schtasks.exe (ONLOGON)."
  try {
    $psCmd = "PowerShell.exe"
    $psArgs = @("-NoProfile","-ExecutionPolicy","Bypass","-File",$updaterPath)
    if (-not [string]::IsNullOrWhiteSpace($MetaUrl)) { $psArgs += @("-MetaUrl",$MetaUrl) }
    $trRaw = $psCmd + " " + ($psArgs -join " ")

    $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Author>$($env:USERNAME)</Author></RegistrationInfo>
  <Triggers><LogonTrigger><Enabled>true</Enabled></LogonTrigger><CalendarTrigger><StartBoundary>$((Get-Date).ToString("yyyy-MM-ddT03:00:00"))</StartBoundary><Enabled>true</Enabled><ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>$($env:USERNAME)</UserId><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings><StartWhenAvailable>true</StartWhenAvailable><Enabled>true</Enabled></Settings>
  <Actions Context="Author"><Exec><Command>PowerShell.exe</Command><Arguments><![CDATA[$trRaw]]></Arguments></Exec></Actions>
</Task>
"@

    $xmlPath = Join-Path $env:TEMP ("sub_task_{0}.xml" -f ([guid]::NewGuid().ToString("N")))
    $xml | Out-File -FilePath $xmlPath -Encoding Unicode

    $p1 = Start-Process -FilePath 'schtasks.exe' -ArgumentList "/Create","/TN",$TaskName,"/XML",$xmlPath,"/F" -NoNewWindow -Wait -PassThru -ErrorAction Stop
    if ($p1.ExitCode -ne 0) { Write-Warning ("schtasks onlogon failed: exit " + $p1.ExitCode) } else { Write-Host "Created OnLogon task via schtasks.exe (XML)." }

    Remove-Item -Path $xmlPath -ErrorAction SilentlyContinue
    Write-Host "Fallback: Scheduled task(s) created via schtasks.exe (per-user)."
  } catch {
    Write-Error "Fallback schtasks.exe failed: $($_.Exception.Message)"
    exit 1
  }
}
    if ($p1.ExitCode -ne 0) { Write-Warning ("schtasks onlogon failed: exit " + $p1.ExitCode) } else { Write-Host "Created OnLogon task via schtasks.exe (XML)." }

    # cleanup
    Remove-Item -Path $xmlPath -ErrorAction SilentlyContinue
    Write-Host "Fallback: Scheduled task(s) created via schtasks.exe (per-user) if not blocked by policy."
  } catch {
    Write-Error "Fallback schtasks.exe also failed: $($_.Exception.Message)"
    exit 1
  }
}
