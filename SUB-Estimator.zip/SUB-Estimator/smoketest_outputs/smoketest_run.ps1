$MetaUrl = $args[0]
$tmp = Join-Path $env:TEMP 'sub_estimator_smoketest'
if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $tmp | Out-Null
Set-Location -Path 'C:\Users\Admin\Desktop\SUB Estimator'
if ($MetaUrl) { .\updater.ps1 -MetaUrl $MetaUrl -InstallDir $tmp } else { .\updater.ps1 -InstallDir $tmp }
Write-Output 'SMOKETEST_DONE'
