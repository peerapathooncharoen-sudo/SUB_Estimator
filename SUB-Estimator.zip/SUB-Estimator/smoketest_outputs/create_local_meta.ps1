param(
  [string]$ZipPath = 'C:\Users\Admin\Desktop\SUB Estimator\dist\SUB_Estimator_program.zip',
  [string]$Version = '',
  [string]$Owner = 'peerapathooncharoen-sudo',
  [string]$Repo = 'SUB_Estimator',
  [string]$Tag = ''    # if provided, metadata.url will point to GitHub release download for this tag
)
$ErrorActionPreference = 'Stop'

# read version from version.txt if not provided
if ([string]::IsNullOrWhiteSpace($Version)) {
  $vfileCandidate = Join-Path (Split-Path $ZipPath -Parent -ErrorAction SilentlyContinue) '..\version.txt'
  $vfileCandidate = (Resolve-Path $vfileCandidate -ErrorAction SilentlyContinue).Path
  if ($vfileCandidate -and (Test-Path $vfileCandidate)) {
    try { $Version = (Get-Content $vfileCandidate -Raw).Trim() } catch {}
  }
  if (-not $Version) {
    $rootV = Join-Path (Split-Path $PSScriptRoot -Parent) 'version.txt'
    if (Test-Path $rootV) { $Version = (Get-Content $rootV -Raw).Trim() }
  }
  if (-not $Version) { $Version = '0.0.0' }
}

if (-not (Test-Path $ZipPath)) { Write-Error "Zip not found: $ZipPath"; exit 1 }

# compute SHA256
$sha = (Get-FileHash -Algorithm SHA256 -Path $ZipPath -ErrorAction Stop).Hash.ToUpper()

# determine URL: prefer GitHub release if Tag provided, otherwise file:/// path to zip
if (-not [string]::IsNullOrWhiteSpace($Tag)) {
  $fileUrl = "https://github.com/$Owner/$Repo/releases/download/$Tag/$(Split-Path $ZipPath -Leaf)"
} else {
  # local file URL (use absolute path)
  $abs = (Resolve-Path $ZipPath).Path
  $fileUrl = "file:///" + ($abs -replace '\\','/')
}

$metaObj = [ordered]@{
  url     = $fileUrl
  version = $Version
  sha256  = $sha
  date    = (Get-Date).ToString("s")
}

$distMetaPath = Join-Path (Split-Path $ZipPath -Parent) 'version.json'
$rootMetaPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'version.json'

$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath $distMetaPath -Encoding UTF8
Write-Output "Wrote dist meta: $distMetaPath"

$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath $rootMetaPath -Encoding UTF8
Write-Output "Wrote root meta: $rootMetaPath"

# temp copy
$metaObj | ConvertTo-Json -Depth 5 | Out-File -FilePath (Join-Path $env:TEMP 'sub_meta_local.json') -Encoding UTF8
Write-Output "Wrote meta to: $env:TEMP\sub_meta_local.json"
