<#
install.ps1 - Install SUB Estimator for current user and register updater scheduled task

Usage:
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -SourceZip .\SUB_Estimator_program.zip -RegisterUpdater
#>
param(
  [string]$SourceZip = '.\SUB_Estimator_program.zip',
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [switch]$RegisterUpdater,
  [string]$TaskName = 'SUB Estimator Updater'    # <- added: allow install to control task name
)

# Resolve SourceZip to absolute path (if possible)
try {
  $resolvedZip = (Resolve-Path -Path $SourceZip -ErrorAction SilentlyContinue)
  if ($resolvedZip) { $SourceZipFull = $resolvedZip.Path } else { $SourceZipFull = (Resolve-Path -Path (Join-Path (Get-Location) $SourceZip) -ErrorAction SilentlyContinue).Path }
} catch { $SourceZipFull = $null }

if (-not $SourceZipFull) { 
  Write-Error "Source zip not found or cannot be resolved: $SourceZip"; exit 1 
}

if (-not (Test-Path $SourceZipFull)) { Write-Error "Source zip not found: $SourceZipFull"; exit 1 }

# Ensure install dir exists
if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir | Out-Null }

try {
  Expand-Archive -Path $SourceZipFull -DestinationPath $InstallDir -Force
  Write-Host "Installed to: $InstallDir"
} catch {
  Write-Error "Failed to extract program zip: $_"
  exit 1
}

# get directory that contains the zip (safe single-string)
try {
  $zipParentDir = [System.IO.Path]::GetDirectoryName($SourceZipFull)
} catch {
  $zipParentDir = $null
}

# write version.txt if version.json is present in the zip (or dist)
$ver = $null
$possibleMeta = @()
if ($zipParentDir) { $possibleMeta += Join-Path -Path $zipParentDir -ChildPath 'version.json' }
$possibleMeta += Join-Path -Path $InstallDir -ChildPath 'version.json'

foreach ($p in $possibleMeta) {
  if (Test-Path $p) {
    try { $m = Get-Content $p -Raw | ConvertFrom-Json; $ver = $m.version; break } catch {}
  }
}
if ($ver) { $ver | Out-File -FilePath (Join-Path $InstallDir 'version.txt') -Encoding UTF8; Write-Host "Wrote version.txt: $ver" }

# Helper: try to locate a helper script in several places (InstallDir, zip parent, current working dir)
function Find-ScriptInPlaces {
  param([string]$name)
  $candidates = @()
  $candidates += Join-Path -Path $InstallDir -ChildPath $name
  if ($zipParentDir) { $candidates += Join-Path -Path $zipParentDir -ChildPath $name }
  $callerDir = (Get-Location).Path
  $candidates += Join-Path -Path $callerDir -ChildPath $name

  foreach ($c in $candidates) {
    if (Test-Path $c) { return (Resolve-Path $c).Path }
  }
  return $null
}

if ($RegisterUpdater) {
  # prefer install-updater-task.ps1 at install root; if not found, try to find and copy it from other locations
  $scriptName = 'install-updater-task.ps1'
  $script = Join-Path $InstallDir $scriptName
  if (-not (Test-Path $script)) {
    $found = Find-ScriptInPlaces -name $scriptName
    if ($found) {
      try {
        Copy-Item -Path $found -Destination $InstallDir -Force
        $script = Join-Path $InstallDir $scriptName
        Write-Host "Copied $scriptName from $found -> $InstallDir"
      } catch {
        Write-Warning "Failed to copy $scriptName from $found -> $InstallDir : $_"
      }
    }
  }

  if (Test-Path $script) {
    # ensure updater.ps1 is present in InstallDir (otherwise copy from known places)
    $updaterName = 'updater.ps1'
    $updaterPath = Join-Path $InstallDir $updaterName
    if (-not (Test-Path $updaterPath)) {
      $foundUpd = Find-ScriptInPlaces -name $updaterName
      if ($foundUpd) {
        try {
          Copy-Item -Path $foundUpd -Destination $InstallDir -Force
          Write-Host "Copied $updaterName from $foundUpd -> $InstallDir"
        } catch {
          Write-Warning "Failed to copy $updaterName from $foundUpd -> $InstallDir : $_"
        }
      } else {
        Write-Warning "updater.ps1 not found in InstallDir or source locations; scheduled task will not be registered."
      }
    }

    # determine metaUrl pointing to installed version.json if present
    $installedMeta = Join-Path $InstallDir 'version.json'
    if (Test-Path $installedMeta) {
      try {
        $abs = (Resolve-Path $installedMeta).Path
        $fileUri = "file:///" + ($abs -replace '\\','/')
        & powershell -NoProfile -ExecutionPolicy Bypass -File $script -InstallDir $InstallDir -MetaUrl $fileUri
      } catch {
        Write-Warning "Failed to invoke $script with MetaUrl: $_"
        & powershell -NoProfile -ExecutionPolicy Bypass -File $script -InstallDir $InstallDir
      }
    } else {
      # fallback: call without meta url (updater will use default or update.config.json)
      & powershell -NoProfile -ExecutionPolicy Bypass -File $script -InstallDir $InstallDir
    }

    # --- Verify scheduled task exists; if not, attempt to create via schtasks (safe args) ---
    Start-Sleep -Seconds 1
    $taskExists = $false
    try {
      $q = schtasks /Query /TN "$TaskName" 2>&1
      if ($LASTEXITCODE -eq 0) { $taskExists = $true }
    } catch { $taskExists = $false }

    if (-not $taskExists) {
      Write-Warning "Scheduled task '$TaskName' not found after installer script. Attempting direct creation via schtasks..."
      try {
        # ensure updater path exists before attempting to create task
        if (-not (Test-Path $updaterPath)) { throw "updater.ps1 not found at $updaterPath; cannot create scheduled task." }

        $updaterFull = (Resolve-Path $updaterPath).Path
        $psCmd = "PowerShell.exe"
        # build argument string safely
        $psArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$updaterFull`""
        if (Test-Path $installedMeta) { $psArgs += " -MetaUrl `"$fileUri`"" }

        # Ensure the TR is a single quoted string for schtasks
        $trRaw = $psCmd + " " + $psArgs
        $trQuoted = '"' + $trRaw + '"'

        $createCmd = "/Create /TN `"$TaskName`" /TR $trQuoted /SC ONLOGON /RL LIMITED /F /RU `"$env:USERNAME`""
        Start-Process -FilePath "schtasks.exe" -ArgumentList $createCmd -NoNewWindow -Wait -ErrorAction Stop

        # also create daily task
        $dailyName = "$TaskName (Daily)"
        $dailyCmd = "/Create /TN `"$dailyName`" /TR $trQuoted /SC DAILY /ST 03:00 /RL LIMITED /F /RU `"$env:USERNAME`""
        Start-Process -FilePath "schtasks.exe" -ArgumentList $dailyCmd -NoNewWindow -Wait -ErrorAction Stop

        Write-Host "Created scheduled tasks via schtasks.exe as fallback."
      } catch {
        Write-Warning "Direct schtasks creation failed: $_"
      }
    } else {
      Write-Host "Scheduled task verified: $TaskName"
    }
  } else {
    Write-Host "install-updater-task.ps1 not found in install dir (searched common locations); skipping scheduled task registration"
  }
}

Write-Host "Install complete. To enable automatic updates, run install-updater-task.ps1 from the install folder (or run this script with -RegisterUpdater)."