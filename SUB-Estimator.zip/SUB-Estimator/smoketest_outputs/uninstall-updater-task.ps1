<# uninstall-updater-task.ps1
Removes the scheduled task created by install-updater-task.ps1 and optionally deletes updater files.
Usage:
  powershell -ExecutionPolicy Bypass -File .\uninstall-updater-task.ps1 [-InstallDir <path>] [-TaskName <name>] [-RemoveFiles]
#>
Param(
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$TaskName = 'SUB Estimator Updater',
  [switch]$RemoveFiles
)

try {
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop
    Write-Host "Scheduled task '$TaskName' removed."
  } else {
    Write-Host "Scheduled task '$TaskName' not found."
  }
} catch {
  Write-Error "Failed to remove scheduled task: $_"
}

if ($RemoveFiles) {
  try {
    if (Test-Path $InstallDir) {
      Remove-Item -Path $InstallDir -Recurse -Force -ErrorAction Stop
      Write-Host "Install directory '$InstallDir' removed."
    } else {
      Write-Host "Install directory '$InstallDir' not found."
    }
  } catch {
    Write-Error "Failed to remove install directory: $_"
  }
}
