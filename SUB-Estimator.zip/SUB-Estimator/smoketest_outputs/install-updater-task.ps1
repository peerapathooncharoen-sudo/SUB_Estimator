<#
install-updater-task.ps1
Installs a per-user scheduled task to run updater.ps1 at user logon.

Usage:
  powershell -ExecutionPolicy Bypass -File .\install-updater-task.ps1 [-MetaUrl 'file:///C:/.../version.json']
#>
Param(
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$TaskName = 'SUB Estimator Updater',
  [string]$MetaUrl = ''   # optional: metadata URL (file:// or https://). If provided it will be passed to updater.ps1
)

$updaterPath = Join-Path $InstallDir 'updater.ps1'
if (-not (Test-Path $updaterPath)) { Write-Error "updater.ps1 not found at $updaterPath" ; exit 1 }

# build argument string, include -MetaUrl when given
$arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$updaterPath`""
if (-not [string]::IsNullOrWhiteSpace($MetaUrl)) {
  $arg += " -MetaUrl `"$MetaUrl`""
}

$action = New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument $arg
$triggerLogon = New-ScheduledTaskTrigger -AtLogOn
$triggerDaily = New-ScheduledTaskTrigger -Daily -At 3:00AM
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive

# Try Register-ScheduledTask first, fallback to schtasks.exe on permission error
try {
  Register-ScheduledTask -Action $action -Trigger $triggerLogon,$triggerDaily -TaskName $TaskName -Principal $principal -Force | Out-Null
  if (-not [string]::IsNullOrWhiteSpace($MetaUrl)) {
    Write-Host "Scheduled task '$TaskName' installed for user $env:USERNAME (AtLogOn + Daily) with MetaUrl: $MetaUrl"
  } else {
    Write-Host "Scheduled task '$TaskName' installed for user $env:USERNAME (AtLogOn + Daily)"
  }
} catch {
  Write-Warning "Register-ScheduledTask failed: $($_.Exception.Message). Attempting fallback using schtasks.exe."
  try {
    # Build ps command and args safely (use array to build then join)
    $psCmd = "PowerShell.exe"
    $psArgs = @("-NoProfile","-ExecutionPolicy","Bypass","-File",$updaterPath)
    if (-not [string]::IsNullOrWhiteSpace($MetaUrl)) { $psArgs += @("-MetaUrl",$MetaUrl) }

    # create the TR string and ensure it is quoted for schtasks
    $trRaw = $psCmd + " " + ($psArgs -join " ")
    $trQuoted = '"' + $trRaw + '"'

    # Build full schtasks command as single string (quote TN and RU)
    $createCmd = "/Create /TN `"$TaskName`" /TR $trQuoted /SC ONLOGON /RL LIMITED /F /RU `"$env:USERNAME`""
    Start-Process -FilePath "schtasks.exe" -ArgumentList $createCmd -NoNewWindow -Wait -ErrorAction Stop

    # also create daily task (03:00) for regular checks (best-effort)
    $dailyName = "$TaskName (Daily)"
    $dailyCmd = "/Create /TN `"$dailyName`" /TR $trQuoted /SC DAILY /ST 03:00 /RL LIMITED /F /RU `"$env:USERNAME`""
    Start-Process -FilePath "schtasks.exe" -ArgumentList $dailyCmd -NoNewWindow -Wait -ErrorAction Stop

    Write-Host "Fallback: Scheduled task(s) created via schtasks.exe for user $env:USERNAME"
  } catch {
    Write-Error "Fallback schtasks.exe also failed: $($_.Exception.Message)"
    exit 1
  }
}
}
