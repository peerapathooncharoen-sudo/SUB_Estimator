<#
updater.ps1 - Simple updater for SUB Estimator

Place this file in the installed application folder (e.g. %LocalAppData%\SUB Estimator) and
create a scheduled task or run-at-login shortcut to run it periodically.

Configuration: edit the $MetaUrl variable to point to your hosted version.json (HTTPS).

Behavior summary:
 - download version.json
 - if remote version > local version -> download zip, verify sha256
 - extract to temp, backup existing install, move new files into place, write version.txt
#>

[CmdletBinding()]
Param(
  # Use GitHub releases "latest" download endpoint so clients always fetch the most recent release metadata.
  [string]$MetaUrl = 'https://github.com/peerapathooncharoen-sudo/SUB_Estimator/releases/latest/download/version.json',
  [string]$InstallDir = "$env:LocalAppData\SUB Estimator",
  [string]$BackupDirBase = "$env:LocalAppData\SUB Estimator_backup"
)

# Files or relative paths to preserve from the existing install when updating.
# Example: @('data\userdb.json','config\secrets.json')
[string[]]$PreserveFiles = @()

function Get-LocalVersion {
  $vfile = Join-Path $InstallDir 'version.txt'
  if (Test-Path $vfile) { return (Get-Content $vfile -ErrorAction SilentlyContinue).Trim() }
  return '0.0.0'
}

function Is-Newer($remote, $local) {
  $r = $remote.Split('.') | ForEach-Object {[int]$_}
  $l = $local.Split('.')  | ForEach-Object {[int]$_}
  for ($i=0; $i -lt [Math]::Max($r.Count,$l.Count); $i++) {
    $ri = if ($i -lt $r.Count) { $r[$i] } else { 0 }
    $li = if ($i -lt $l.Count) { $l[$i] } else { 0 }
    if ($ri -gt $li) { return $true }
    if ($ri -lt $li) { return $false }
  }
  return $false
}

try {
  # Ensure TLS 1.2 for HTTPS requests (helps on older Windows/PowerShell setups)
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
  function Write-Log($msg) {
    try { $log = Join-Path $InstallDir 'updater.log'; $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; "$ts`t$msg" | Out-File -FilePath $log -Append -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    Write-Output $msg
  }

  Write-Log "Updater: checking $MetaUrl ..."
  # Support local file URLs or local paths for testing (file:///C:/path/to/version.json or C:\path)
  if ($MetaUrl -like 'file:*' -or (Test-Path $MetaUrl)) {
    try {
      # normalize file:// URIs
      if ($MetaUrl -like 'file:*') {
        $u = [uri]$MetaUrl
        $path = $u.LocalPath
      } else {
        $path = $MetaUrl
      }
      Write-Log "Reading metadata from local file: $path"
      $meta = Get-Content -Path $path -Raw -ErrorAction Stop
    } catch {
      throw "Failed to read local metadata file: $_"
    }
  } else {
    $meta = Invoke-RestMethod -Uri $MetaUrl -UseBasicParsing -ErrorAction Stop
  }

  # If the server served JSON as text (or included a UTF8 BOM), ConvertFrom-Json
  if ($meta -is [string]) {
    $raw = $meta.Trim()
    # strip UTF8 BOM bytes (EF BB BF) and Unicode BOM (FEFF) if present
    $raw = $raw -replace "^[\xEF\xBB\xBF]+",""
    $raw = $raw -replace '^[\uFEFF]+',''
    try {
      $meta = $raw | ConvertFrom-Json -ErrorAction Stop
    } catch {
      throw "Failed to parse version metadata as JSON. Raw data starts with: $($raw.Substring(0,[Math]::Min(80,$raw.Length))) - error: $_"
    }
  }

  $remoteVersion = $meta.version
  $remoteUrl = $meta.url
  $remoteSha = $meta.sha256

  if (-not $remoteVersion -or -not $remoteUrl -or -not $remoteSha) {
    throw "Invalid metadata received from $MetaUrl - missing required fields (version, url, sha256)"
  }

  $localVersion = Get-LocalVersion
  Write-Log "Local version: $localVersion  Remote version: $remoteVersion"

  if (-not (Is-Newer $remoteVersion $localVersion)) {
    Write-Output "Updater: up-to-date."
    exit 0
  }

  $tmpZip = Join-Path $env:TEMP ("sub_update_{0}.zip" -f ([guid]::NewGuid().ToString()))
  Write-Log "Downloading $remoteUrl -> $tmpZip"
  Invoke-WebRequest -Uri $remoteUrl -OutFile $tmpZip -UseBasicParsing -ErrorAction Stop

  $h = (Get-FileHash -Algorithm SHA256 -Path $tmpZip).Hash.ToUpper()
  if ($h -ne $remoteSha.ToUpper()) { throw "SHA256 mismatch (expected $remoteSha, got $h)" }

  $extractDir = Join-Path $env:TEMP ("sub_update_extract_{0}" -f ([guid]::NewGuid().ToString()))
  New-Item -ItemType Directory -Path $extractDir | Out-Null
  Expand-Archive -Path $tmpZip -DestinationPath $extractDir -Force

  # Prepare safe install: extract into a versioned folder sibling to InstallDir, then swap
  $parent = Split-Path -Parent $InstallDir
  if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent | Out-Null }

  $safeDir = Join-Path $parent ("SUB Estimator_new_{0}" -f ([guid]::NewGuid().ToString()))
  Write-Log "Preparing safe install in $safeDir"
  New-Item -ItemType Directory -Path $safeDir | Out-Null

  try {
    Copy-Item -Path (Join-Path $extractDir '*') -Destination $safeDir -Recurse -Force -ErrorAction Stop
  } catch {
    throw "Failed to copy extracted files to safe install dir: $_"
  }

  # If user configured files to preserve, try to copy them from existing install into the safeDir
  if ($PreserveFiles -and $PreserveFiles.Count -gt 0) {
    Write-Log "Preserve: copying specified files into safe install before swap"
    foreach ($p in $PreserveFiles) {
      $src = Join-Path $InstallDir $p
      $dst = Join-Path $safeDir $p
      try {
        if (Test-Path $src) {
          New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
          Copy-Item -Path $src -Destination $dst -Force -Recurse -ErrorAction Stop
          Write-Log "Preserve: copied $p"
        } else {
          Write-Log "Preserve: not found (skipped) $p"
        }
      } catch {
        Write-Log "Preserve: failed to copy $p - $_"
      }
    }
  }

  # Check for running processes that may lock files (basic heuristic: look for files with open handles by trying to open for exclusive write)
  function Test-FileLocked([string]$filePath) {
    try {
      $stream = [System.IO.File]::Open($filePath, 'Open', 'ReadWrite', 'None')
      $stream.Close()
      return $false
    } catch {
      return $true
    }
  }

  $locked = $false
  Get-ChildItem -Path $safeDir -Recurse -File | ForEach-Object {
    $rel = $_.FullName
    # map to installed path name that would be overwritten
    $target = Join-Path $InstallDir ($_.FullName.Substring($safeDir.Length).TrimStart('\'))
    if (Test-Path $target) {
      if (Test-FileLocked $target) {
        Write-Log "File locked, skipping update now: $target"
        $locked = $true
      }
    }
  }

  if ($locked) {
    # Attempt to notify interactive user (if possible), then cleanup and abort
    try {
      if ([System.Environment]::UserInteractive) {
        try {
          Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
          $msg = "SUB Estimator: Update blocked because files are in use.`nPlease close SUB Estimator and try again."
          $caption = "SUB Estimator Update"
          [System.Windows.Forms.MessageBox]::Show($msg, $caption, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
        } catch {
          # ignore UI failures
        }
      }
    } catch {}

    # cleanup safeDir & extracted archive
    Remove-Item -Path $safeDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $tmpZip -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $extractDir -Recurse -Force -ErrorAction SilentlyContinue
    throw "One or more files are locked. Update aborted to avoid partial install."
  }

  # backup current install
  if (Test-Path $InstallDir) {
    $ts = Get-Date -Format "yyyyMMddHHmmss"
    $bak = "${BackupDirBase}_$ts"
    Write-Log "Backing up current install to $bak"
    Remove-Item -Recurse -Force $bak -ErrorAction SilentlyContinue
    # Temporarily change working directory to avoid locking InstallDir (script or current location may be inside it)
    $origLocation = Get-Location
    try { Set-Location $env:TEMP } catch {}
    try {
      Move-Item -Path $InstallDir -Destination $bak -Force -ErrorAction Stop
    } catch {
      Write-Log "Move-Item to backup failed: $_. Attempting copy fallback."
      # Attempt fallback: copy InstallDir to backup (best-effort), then try to remove InstallDir
      try {
        Copy-Item -Path $InstallDir -Destination $bak -Recurse -Force -ErrorAction Stop
        Write-Log "Copied InstallDir to backup $bak"
      } catch {
        Write-Log "Copy to backup failed: $_"
      }

      # Try removing InstallDir with retries
      $removed = $false
      for ($i=0; $i -lt 5; $i++) {
        try {
          Remove-Item -Path $InstallDir -Recurse -Force -ErrorAction Stop
          $removed = $true
          break
        } catch {
          Start-Sleep -Seconds 1
        }
      }

      if (-not $removed) {
        Write-Log "Could not remove InstallDir; attempting to copy new files into place (overwrite)."
        try {
          Copy-Item -Path (Join-Path $safeDir '*') -Destination $InstallDir -Recurse -Force -ErrorAction Stop
          Write-Log "Copied new files into existing InstallDir"
        } catch {
          # cleanup safeDir and throw
          Remove-Item -Path $safeDir -Recurse -Force -ErrorAction SilentlyContinue
          try { Set-Location $origLocation } catch {}
          throw "Failed to backup/install: $_"
        }
      } else {
        # If removed successfully, move safeDir into place
        try {
          Move-Item -Path $safeDir -Destination $InstallDir -Force -ErrorAction Stop
        } catch {
          Remove-Item -Path $safeDir -Recurse -Force -ErrorAction SilentlyContinue
          try { Set-Location $origLocation } catch {}
          throw "Failed to move new files into place after removing InstallDir: $_"
        }
      }

      try { Set-Location $origLocation } catch {}
    }
  }

  # Move safeDir into place (rename)
  try {
    Move-Item -Path $safeDir -Destination $InstallDir -Force -ErrorAction Stop
  } catch {
    Write-Log "Failed to move new files into place: $_"
    # attempt rollback from backup
    try {
      if (Test-Path $bak) {
        Move-Item -Path $bak -Destination $InstallDir -Force -ErrorAction Stop
        Write-Log "Rollback: restored backup to $InstallDir"
      }
    } catch {
      Write-Log "Rollback failed: $_"
    }
    Remove-Item -Path $tmpZip -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $extractDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $safeDir -Recurse -Force -ErrorAction SilentlyContinue
    throw "Update failed and rollback attempted. See logs."
  }

  # write version
  $remoteVersion | Out-File -FilePath (Join-Path $InstallDir 'version.txt') -Encoding UTF8

  Remove-Item -Path $tmpZip -Force -ErrorAction SilentlyContinue
  Remove-Item -Path $extractDir -Recurse -Force -ErrorAction SilentlyContinue

  Write-Log "Update to $remoteVersion completed."
} catch {
  Write-Log "Updater failed: $_"
  exit 1
}
