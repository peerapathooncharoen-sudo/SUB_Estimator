$src = Join-Path $env:TEMP 'sub_estimator_smoketest'
$dst = 'c:\Users\Admin\Desktop\SUB Estimator\smoketest_outputs'
if (Test-Path $dst) { Remove-Item -Recurse -Force $dst -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $dst | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "Copied smoketest outputs to: $dst"
Get-ChildItem -Path $dst | Select-Object Name,Length | Format-Table
