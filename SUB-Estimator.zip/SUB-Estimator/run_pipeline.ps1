cd 'C:\Users\Admin\Desktop\SUB Estimator'
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\do_everything_local.ps1 -Version 1.2.0
