param(
  [switch]$NoLog,
  [string]$LogPath = "$PSScriptRoot\run_steps_output.txt"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# determine project root (location of this script)
$ThisFile = $MyInvocation.MyCommand.Definition
$ProjectRoot = Split-Path -Parent $ThisFile
Set-Location -Path $ProjectRoot

if ($NoLog) {
  # mark environment so child scripts can detect and skip writing logs
  $env:SUB_NO_LOG = '1'
}

# initialize log (overwrite)
if (-not $NoLog) {
  try {
    $header = "RunSteps log started: $((Get-Date).ToString('s'))"
    $null = New-Item -Path $LogPath -ItemType File -Force -ErrorAction Stop
    Add-Content -Path $LogPath -Value $header -Encoding UTF8
  } catch {
    Write-Warning "Unable to create log file $LogPath : $($_.Exception.Message)"
  }
}

function Write-LogLine([string]$line) {
  $ts = (Get-Date).ToString('s')
  $entry = "$ts`t$line"
  Write-Host $line
  if (-not $NoLog) {
    try { Add-Content -Path $LogPath -Value $entry -Encoding UTF8 -ErrorAction Stop } catch { Write-Warning "Log write failed: $($_.Exception.Message)" }
  }
}

function Run-PSFile([string]$path, [string[]]$args = @()) {
  if (-not (Test-Path $path)) { throw "Script not found: $path" }
  $full = (Resolve-Path $path).Path
  $cmdLine = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$full`" $($args -join ' ')"
  Write-LogLine "=== START: $full $($args -join ' ') ==="
  try {
    # capture stdout + stderr
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $full @args 2>&1
    if ($out -is [System.Array]) {
      foreach ($ln in $out) { Write-LogLine $ln.ToString() }
    } else {
      Write-LogLine $out.ToString()
    }
    Write-LogLine "=== END: $full (exit OK) ===`n"
  } catch {
    $err = $_.Exception
    Write-LogLine "ERROR running $full : $($err.Message)"
    Write-LogLine "Stack: $($err.StackTrace)"
    Write-LogLine "=== END: $full (exit ERROR) ===`n"
    throw
  }
}

try {
  Write-LogLine "Project root: $ProjectRoot"

  # 1) ดาวน์โหลดไลบรารีไปที่ lib/
  $dl = Join-Path $ProjectRoot 'scripts\download-libs.ps1'
  if (Test-Path $dl) {
    Run-PSFile $dl
  } else { Write-LogLine "download-libs.ps1 not found, skipping." }

  # 2) สร้าง ZIP และ metadata (dist/version.json + root version.json)
  $build = Join-Path $ProjectRoot 'scripts\build-and-publish.ps1'
  Run-PSFile $build @('-Version','1.2.0','-Force')

  # 3) สร้าง/ยืนยัน metadata (ถ้าต้องการ)
  $createMeta = Join-Path $ProjectRoot 'create_local_meta.ps1'
  $zipPath = Join-Path $ProjectRoot 'dist\SUB_Estimator_program.zip'
  if (Test-Path $createMeta -and Test-Path $zipPath) {
    Run-PSFile $createMeta @('-ZipPath', $zipPath, '-Version', '1.2.0')
  } else {
    Write-LogLine "create_local_meta.ps1 or zip missing; skipping metadata creation."
  }

  # 4) รัน smoketest โดยให้ updater ใช้ dist/version.json (local file URI)
  $distMeta = Join-Path $ProjectRoot 'dist\version.json'
  if (-not (Test-Path $distMeta)) { throw "dist/version.json missing; cannot run smoketest" }
  $metaAbs = (Resolve-Path $distMeta).Path
  $fileUri = "file:///" + ($metaAbs -replace '\\','/')
  $smoke = Join-Path $ProjectRoot 'smoketest_run.ps1'
  if (Test-Path $smoke) {
    Run-PSFile $smoke @($fileUri)
  } else {
    Write-LogLine "smoketest_run.ps1 not found; skipping smoketest."
  }

  # 5) เก็บผล smoketest ลง smoketest_outputs/
  $fetch = Join-Path $ProjectRoot 'fetch_smoketest_outputs.ps1'
  if (Test-Path $fetch) {
    Run-PSFile $fetch
  } else {
    Write-LogLine "fetch_smoketest_outputs.ps1 not found; skipping fetch."
  }

  # 6) ดูรายงานสรุป (ถ้ามี)
  $report = Join-Path $ProjectRoot 'smoketest_outputs\report.txt'
  if ($env:SUB_NO_LOG) {
    Write-LogLine "`nLogs are disabled (NoLog). Report file may not be written."
  } else {
    if (Test-Path $report) {
      Write-LogLine "`n--- Smoketest report ---"
      try {
        $content = Get-Content -Path $report -Raw -ErrorAction Stop
        Write-LogLine $content
      } catch { Write-LogLine "Failed to read report.txt: $($_.Exception.Message)" }
    } else {
      Write-LogLine "`nreport.txt not found — check smoketest_outputs/ folder"
    }
  }

  Write-LogLine "`nAll steps completed successfully."
} catch {
  Write-LogLine "Run steps failed: $($_.Exception.Message)"
  exit 1
} finally {
  if (-not $NoLog) {
    Write-LogLine "Log saved to: $LogPath"
  }
}
